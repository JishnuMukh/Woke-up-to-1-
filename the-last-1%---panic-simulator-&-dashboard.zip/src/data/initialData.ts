import { 
  ChatThread, 
  MapDestination, 
  SocialPost, 
  ChecklistItem, 
  SimState, 
  EndingResult, 
  PhoneModelConfig, 
  PhonePresetId,
  StreetDilemma,
  ActiveIncomingCall,
  ScenarioConfig,
  ScenarioId
} from '../types';

export function generateRandomSecurityCode(): string {
  // Generate random 4-digit code (e.g. #7392, #4829, #8163)
  const num = Math.floor(1000 + Math.random() * 9000);
  return `#${num}`;
}

export const SCENARIOS: ScenarioConfig[] = [
  {
    id: 'interview',
    title: 'The High-Stakes Job Interview',
    subtitle: 'Apex Tech Executive Suite 400',
    tag: 'Career Milestone · 8:05 AM',
    desc: 'You woke up with under 10% battery. You must reach Suite 400 at Apex Tower by 9:15 AM sharp and pass security doors with the secret PIN.',
    icon: '👔',
    targetName: 'Apex Tech Suite 400',
    targetLocation: 'Apex Tech Tower (4th Floor)',
    targetTimeFormatted: '9:15 AM',
    startMinutes: 485, // 8:05 AM
    targetMinutes: 555, // 9:15 AM
    contactName: 'Mr. Sterling (Partner)',
    contactAvatar: '👔',
    contactRole: 'Apex Tech Executive Suite',
    codeContext: 'Elevator Security PIN',
    initialBriefing: 'Reply to Mr. Sterling, navigate to Apex Tower, find the elevator PIN, and arrive before 9:15 AM.'
  },
  {
    id: 'date',
    title: 'The 1% Blind Date (Rooftop Romance)',
    subtitle: 'Starlight Rooftop Lounge (Table 14)',
    tag: 'Love & Vulnerability · 7:45 PM',
    desc: 'Friday evening in the bustling city. You are meeting Jordan for a first date at 8:30 PM with less than 10% battery. Table 14 requires a secret reservation PIN. Seductive social feeds and profile stalking threaten to consume your final battery. Can you disconnect from the screen and show up authentically in real life?',
    icon: '🌹',
    targetName: 'Starlight Rooftop (Table 14)',
    targetLocation: 'Starlight Rooftop Terrace',
    targetTimeFormatted: '8:30 PM',
    startMinutes: 1185, // 7:45 PM
    targetMinutes: 1230, // 8:30 PM (45 minutes window!)
    contactName: 'Jordan (Your Date ❤️)',
    contactAvatar: '🌹',
    contactRole: 'Waiting at Table 14',
    codeContext: 'Table Reservation PIN',
    initialBriefing: 'Jordan is waiting at Table 14. Find the reservation PIN via Jordan\'s texts, Pulse stories, or the hostess stand, and arrive before 8:30 PM.'
  },
  {
    id: 'farewell',
    title: 'The Midnight Pier Farewell',
    subtitle: 'Pier 9 Harbor Gate (Slip B-42)',
    tag: 'Lifelong Friendship & Regret · 10:45 PM',
    desc: 'Your childhood best friend Leo is boarding an ocean vessel to Tokyo tonight at 11:30 PM. For two years, your friendship atrophied into superficial story likes and meme reactions. Leo texted: "Slip B-42 locks at 11:30 PM sharp. Gate PIN is #XXXX. Real friends show up in real life." With under 8% battery, algorithmic feeds and group chat drama tempt you to stare down at glass. Can you disconnect and say goodbye in person?',
    icon: '⚓',
    targetName: 'Pier 9 Harbor Gate (Slip B-42)',
    targetLocation: 'Pier 9 International Terminal',
    targetTimeFormatted: '11:30 PM',
    startMinutes: 1365, // 10:45 PM
    targetMinutes: 1410, // 11:30 PM (45 minutes window!)
    contactName: 'Leo (Childhood Best Friend 🌊)',
    contactAvatar: '⚓',
    contactRole: 'Boarding Slip B-42 for Tokyo',
    codeContext: 'Harbor Gate Security PIN',
    initialBriefing: 'Leo departs for Tokyo at 11:30 PM. Find the Slip B-42 gate PIN, traverse the long foggy docks, resist doomscrolling, and give your oldest friend a real hug.'
  }
];

export const PHONE_MODELS: PhoneModelConfig[] = [
  {
    id: 'iphone18pro',
    name: 'iPhone 18 Pro (Titanium)',
    tag: 'Dynamic Island · 120Hz ProMotion',
    desc: 'Titanium alloy chassis, 94% battery health. Authentic iOS squircle icons. Push notifications constantly tempt you with FOMO. Starts at 7.5% battery.',
    os: 'ios',
    batteryHealth: 94,
    drainMultiplier: 0.72,
    startingBattery: 7.5,
    bezelStyle: 'dynamic_island',
    perk: 'Dynamic Island previews incoming alerts with minimal screen wake energy.',
    drawback: 'Ultra-fluid 120Hz refresh rate makes algorithmic feeds dangerously addictive.',
    chassisColor: '#1c1917',
    accentColor: '#38bdf8'
  },
  {
    id: 'foldable',
    name: 'Foldable Z-Flip',
    tag: 'Crease Display · Dual Battery Cells',
    desc: 'Dual AMOLED displays consume high power. Screen has a visible hinge crease. Circular Android icons. Starts at 6.0% battery.',
    os: 'android',
    batteryHealth: 78,
    drainMultiplier: 0.82,
    startingBattery: 6.0,
    bezelStyle: 'fold_crease',
    perk: 'Small outer cover screen checks time without waking the power-hungry main panel.',
    drawback: 'Unfolding the main screen triggers immediate dopamine craving to scroll.',
    chassisColor: '#312e81',
    accentColor: '#a855f7'
  },
  {
    id: 'android2017',
    name: '2017 Android (Chipped Corner)',
    tag: 'Swollen Battery · Cracked Glass',
    desc: 'Battery health 58%. Corner glass is cracked. Material Design circular icons. Random voltage sag under heavy tasks. Starts at 4.2% battery.',
    os: 'android',
    batteryHealth: 58,
    drainMultiplier: 0.95,
    startingBattery: 4.2,
    bezelStyle: 'chin_bezel',
    perk: 'Ultra Power Saving mode drops the display to high-efficiency greyscale.',
    drawback: 'Noticeable voltage sag (-0.08%) whenever camera flash or GPS radio activates.',
    chassisColor: '#111827',
    accentColor: '#22c55e',
    hasCrackOverlay: true
  },
  {
    id: 'iphone7',
    name: 'Degrading iPhone 7',
    tag: 'Physical Home Button · Thick Bezels',
    desc: 'Battery health 49%. Chassis runs hot to the touch. Features iOS icons and the classic tactile circular Home Button. Starts at 3.0% battery!',
    os: 'ios',
    batteryHealth: 49,
    drainMultiplier: 1.10,
    startingBattery: 3.0,
    bezelStyle: 'classic_home_button',
    perk: 'Clickable tactile home button returns to safety without swipe navigation lag.',
    drawback: 'Silicon heats up rapidly; continuous screen time can trigger thermal freeze.',
    chassisColor: '#27272a',
    accentColor: '#eab308'
  }
];

export function getInitialChats(scenarioId: ScenarioId, code: string): ChatThread[] {
  if (scenarioId === 'date') {
    return [
      {
        id: "jordan",
        name: "Jordan (Your Date ❤️)",
        avatar: "🌹",
        subtitle: "Waiting at Table 14",
        unread: true,
        messages: [
          { sender: "them", text: "Hey! Just arrived at Starlight Rooftop. It is so pretty tonight! ✨" },
          { 
            sender: "them", 
            text: `Hostess says our terrace reservation code is ${code}. Are you on your way?`,
            hasAddress: true,
            addressText: "Table 14, Starlight Rooftop Lounge",
            mapsTarget: "starlight"
          }
        ],
        replies: [
          {
            text: "On my way right now! Can't wait to meet you in person.",
            batteryCost: 0.03,
            timeCost: 2,
            stressDelta: -8,
            responseDelay: 1800,
            response: "Awesome! I'm by the terrace fountain. Take your time and get here safe!"
          },
          {
            text: "Running tight on phone battery (under 10%), headed straight to Table 14!",
            batteryCost: 0.03,
            timeCost: 2,
            stressDelta: -2,
            responseDelay: 2000,
            response: "Haha no worries at all! Just look for the emerald jacket by the fountain!"
          },
          {
            text: "Navigating evening traffic, will be there right before 8:30!",
            batteryCost: 0.03,
            timeCost: 2,
            stressDelta: 4,
            responseDelay: 2200,
            response: "Sounds great! I'll have two glasses of sparkling cider waiting."
          }
        ]
      },
      {
        id: "alex",
        name: "Alex (Best Friend)",
        avatar: "🥂",
        subtitle: "Online",
        unread: true,
        messages: [
          { sender: "them", text: "Jordan is super genuine and down to earth. Do NOT doomscroll their profile!" },
          { sender: "them", text: "Put your phone in your pocket and just be your authentic self. You've got this!" }
        ],
        replies: [
          {
            text: "Thanks Alex! Taking a deep breath and walking to the rooftop now.",
            batteryCost: 0.02,
            timeCost: 1,
            stressDelta: -6,
            responseDelay: 1600,
            response: "Go charm their socks off! Have the best night! 💕"
          }
        ]
      },
      {
        id: "hostess",
        name: "Starlight Lounge Hostess Desk",
        avatar: "🍸",
        subtitle: "Rooftop Terrace Desk",
        unread: false,
        messages: [
          { sender: "them", text: `Reservation Confirmation: Table 14 is reserved under PIN ${code}. Elevator to 12th floor rooftop opens at 7:30 PM.` }
        ],
        replies: [
          {
            text: "Thank you! Arriving shortly.",
            batteryCost: 0.01,
            timeCost: 1,
            stressDelta: -2,
            responseDelay: 1500,
            response: "We look forward to welcoming you."
          }
        ]
      }
    ];
  }

  if (scenarioId === 'farewell') {
    return [
      {
        id: "leo",
        name: "Leo (Childhood Best Friend 🌊)",
        avatar: "⚓",
        subtitle: "Boarding Slip B-42",
        unread: true,
        messages: [
          { sender: "them", text: "Hey... 45 minutes until the ship departs for Tokyo. Are you really not coming to say goodbye?" },
          { 
            sender: "them", 
            text: `Slip B-42 turnstile is locked by port security. Gate keypad PIN is ${code}. Please don't just react with an emoji—come hug me for real.`,
            hasAddress: true,
            addressText: "Slip B-42, Pier 9 Terminal",
            mapsTarget: "pier"
          }
        ],
        replies: [
          {
            text: "Running to Pier 9 right now Leo! I wouldn't let you leave without a real hug.",
            batteryCost: 0.03,
            timeCost: 2,
            stressDelta: -8,
            responseDelay: 1800,
            response: "Really?? Thank you... I'm by the luggage ramp at Slip B-42. Hurry!"
          },
          {
            text: "My phone battery is under 8%, saving every drop to get to the pier!",
            batteryCost: 0.03,
            timeCost: 2,
            stressDelta: -2,
            responseDelay: 2000,
            response: "No worries about the phone, just get here safe before 11:30 PM!"
          },
          {
            text: "I'm so sorry we let screens get between us. Sprinting down the boardwalk!",
            batteryCost: 0.03,
            timeCost: 2,
            stressDelta: -10,
            responseDelay: 2100,
            response: "Me too. Can't wait to see your face in person after all this time."
          }
        ]
      },
      {
        id: "mom",
        name: "Mom ❤️",
        avatar: "👩",
        subtitle: "Mobile",
        unread: true,
        messages: [
          { sender: "them", text: "Honey, Leo's mother called me. He was really hoping to see you before his move." },
          { sender: "them", text: "Don't let screen habits keep you from being there for childhood friends. Put the phone down and run to the pier!" }
        ],
        replies: [
          {
            text: "Headed to Pier 9 right now Mom. Real friendships matter most.",
            batteryCost: 0.02,
            timeCost: 1,
            stressDelta: -8,
            responseDelay: 1600,
            response: "That's my child! Give him a giant hug from our whole family! 💕"
          }
        ]
      },
      {
        id: "squad",
        name: "The Nostalgia Squad 🍻",
        avatar: "🌊",
        subtitle: "Group Chat (4 Online)",
        unread: true,
        messages: [
          { sender: "them", text: "Leo is livestreaming his departure on Pulse right now!" },
          { sender: "them", text: "Wait, aren't you in the same city? Why are you typing in a group chat? Go to Pier 9!!" }
        ],
        replies: [
          {
            text: "Logging off the chat right now—running to the dock in person!",
            batteryCost: 0.02,
            timeCost: 1,
            stressDelta: -6,
            responseDelay: 1500,
            response: "YES! Real life > Discord! Go get 'em!"
          }
        ]
      },
      {
        id: "port_security",
        name: "Pier 9 Port Dispatch",
        avatar: "🚢",
        subtitle: "Automated Terminal Access",
        unread: false,
        messages: [
          { sender: "them", text: `Harbor Notice: International vessel departures at Slip B-42 require visitor turnstile PIN ${code}. Docks lock at 11:30 PM.` }
        ],
        replies: [
          {
            text: "Noted, badge code confirmed.",
            batteryCost: 0.01,
            timeCost: 1,
            stressDelta: -2,
            responseDelay: 1200,
            response: "Harbor master logged."
          }
        ]
      }
    ];
  }

  // Default: Interview Scenario
  return [
    {
      id: "boss",
      name: "Mr. Sterling (Apex Partner)",
      avatar: "👔",
      subtitle: "Apex Tech Executive Suite",
      unread: true,
      messages: [
        { sender: "them", text: "Good morning. Reminder: our partner panel begins at 9:15 AM sharp in Suite 400." },
        { 
          sender: "them", 
          text: `Security glass doors require elevator code ${code}. Are you on your way?`, 
          hasAddress: true, 
          addressText: "Suite 400, Apex Tech Tower", 
          mapsTarget: "apex" 
        }
      ],
      replies: [
        {
          text: "Yes, on my way right now! Looking forward to meeting in person.",
          batteryCost: 0.03,
          timeCost: 2,
          stressDelta: -5,
          flag: "repliedPoliteToBoss",
          responseDelay: 2000,
          response: "Excellent. Reception has your visitor badge ready. See you shortly."
        },
        {
          text: "Running tight on battery (under 10%), but headed to Suite 400 now!",
          batteryCost: 0.03,
          timeCost: 2,
          stressDelta: 1,
          flag: "repliedLowBatteryToBoss",
          responseDelay: 2200,
          response: "Understood. The 4th floor conference room has outlets at every seat."
        },
        {
          text: "Stuck in transit, will be there right at 9:15!",
          batteryCost: 0.03,
          timeCost: 2,
          stressDelta: 6,
          flag: "repliedStuckToBoss",
          responseDelay: 2400,
          response: "Please don't be late; the VP has a hard stop at 9:45."
        }
      ]
    },
    {
      id: "mom",
      name: "Mom ❤️",
      avatar: "👩",
      subtitle: "Mobile",
      unread: true,
      messages: [
        { sender: "them", text: "Good luck with your interview today sweetie! Did you eat a good breakfast?" },
        { sender: "them", text: "Put your phone away, take a deep breath, and look people in the eye. You've got this! Call me after!" }
      ],
      replies: [
        {
          text: "Thanks Mom! Ate an apple, feeling ready. Will call you right after in person!",
          batteryCost: 0.02,
          timeCost: 1,
          stressDelta: -8,
          responseDelay: 2000,
          response: "Proud of you honey! Knock 'em dead! 💕"
        },
        {
          text: "Phone is really low on battery, saving power for the address!",
          batteryCost: 0.02,
          timeCost: 1,
          stressDelta: -2,
          responseDelay: 1800,
          response: "Okay be careful! Don't forget you can always ask people for directions!"
        }
      ]
    },
    {
      id: "maya",
      name: "Maya (Roommate)",
      avatar: "🎨",
      subtitle: "Online",
      unread: false,
      messages: [
        { sender: "them", text: "Hey! Did you take my white phone charger from the kitchen counter??" },
        { sender: "them", text: "Mine is missing and I'm at 14% 😭" }
      ],
      replies: [
        {
          text: "No! I couldn't find my charger either, left with under 10%!",
          batteryCost: 0.02,
          timeCost: 1,
          stressDelta: 3,
          responseDelay: 2000,
          response: "Omg our apartment is cursed. Good luck at Apex today though!!"
        },
        {
          text: "I think it slipped behind the kitchen couch. Check there!",
          batteryCost: 0.02,
          timeCost: 1,
          stressDelta: -1,
          responseDelay: 2000,
          response: "Found it!! You're a lifesaver. Go crush that interview!"
        }
      ]
    },
    {
      id: "reception",
      name: "Apex Tower Security Desk",
      avatar: "🏢",
      subtitle: "Front Desk & Visitor Access",
      unread: false,
      messages: [
        { sender: "them", text: `Visitor Notice: Apex Tech Tower 4th Floor elevator glass gate is currently secured. Security keypad PIN is ${code}.` },
        { sender: "them", text: "If you do not have your phone on arrival, simply speak to the uniformed receptionist at the central marble desk." }
      ],
      replies: [
        {
          text: "Thank you! I will badge in on the 4th floor.",
          batteryCost: 0.02,
          timeCost: 1,
          stressDelta: -4,
          responseDelay: 1800,
          response: "Have a great meeting!"
        }
      ]
    }
  ];
}

export const INITIAL_CHATS = getInitialChats('interview', '#4829');

export function getMapDestinations(scenarioId: ScenarioId): MapDestination[] {
  if (scenarioId === 'date') {
    return [
      {
        id: "starlight",
        name: "Starlight Rooftop Lounge (Table 14)",
        category: "Date Venue",
        icon: "🌹",
        etaMins: 28, // Significantly longer walk as requested!
        distanceKm: "2.2 km",
        batteryCost: 0.28,
        description: "Panoramic rooftop terrace overlooking city lights. Table 14 reservation requires secret PIN.",
        isTarget: true,
        hasOutlet: true,
        pinPos: { top: "25%", left: "74%" },
        svgPos: { x: 252, y: 55 }
      },
      {
        id: "boutique",
        name: "Velvet Floral Boutique",
        category: "Flowers & Gifts",
        icon: "💐",
        etaMins: 10,
        distanceKm: "0.6 km",
        batteryCost: 0.09,
        description: "Fresh red roses and cards. Buying a single rose ($4.50) creates an unforgettable first impression.",
        hasOutlet: false,
        pinPos: { top: "45%", left: "45%" },
        svgPos: { x: 150, y: 110 }
      },
      {
        id: "cafe",
        name: "Neon Bean Corner Café",
        category: "Coffee & Power",
        icon: "☕",
        etaMins: 11,
        distanceKm: "0.8 km",
        batteryCost: 0.10,
        description: "Customer wall outlets & Wi-Fi. The friendly barista shares their power strip with kind people.",
        hasOutlet: true,
        pinPos: { top: "52%", left: "32%" },
        svgPos: { x: 119, y: 120 }
      },
      {
        id: "metro",
        name: "Central Metro Transit Hub",
        category: "Express Subway",
        icon: "🚇",
        etaMins: 12,
        distanceKm: "0.9 km",
        batteryCost: 0.08,
        description: "Express Line 2 stops directly beneath Starlight Rooftop Tower. Fast 4-minute train ride.",
        hasOutlet: false,
        pinPos: { top: "68%", left: "24%" },
        svgPos: { x: 82, y: 163 }
      }
    ];
  }

  if (scenarioId === 'farewell') {
    return [
      {
        id: "pier",
        name: "Pier 9 Harbor Gate (Slip B-42)",
        category: "Harbor Departure Slip",
        icon: "⚓",
        etaMins: 30, // Long trek down misty docks
        distanceKm: "2.4 km",
        batteryCost: 0.30,
        description: "International cargo & passenger slip. Turnstiles require gate PIN. Ship departs at 11:30 PM sharp.",
        isTarget: true,
        hasOutlet: true,
        pinPos: { top: "25%", left: "74%" },
        svgPos: { x: 252, y: 55 }
      },
      {
        id: "lighthouse",
        name: "Old Pier Lighthouse & Bench",
        category: "Scenic Lookout",
        icon: "🏮",
        etaMins: 12,
        distanceKm: "0.8 km",
        batteryCost: 0.10,
        description: "Where you and Leo used to skip stones. A kind night fisherman has a portable battery pack.",
        hasOutlet: true,
        pinPos: { top: "45%", left: "45%" },
        svgPos: { x: 150, y: 110 }
      },
      {
        id: "bodega",
        name: "Harbor 24/7 Neon Bodega",
        category: "Late Night Store",
        icon: "🏪",
        etaMins: 10,
        distanceKm: "0.7 km",
        batteryCost: 0.09,
        description: "Hot drinks and snacks. The friendly night cashier lets you charge phone at the register.",
        hasOutlet: true,
        pinPos: { top: "52%", left: "32%" },
        svgPos: { x: 119, y: 120 }
      },
      {
        id: "tram",
        name: "Waterfront Night Tram Hub",
        category: "Harbor Tram",
        icon: "🚋",
        etaMins: 11,
        distanceKm: "0.9 km",
        batteryCost: 0.08,
        description: "Boardwalk night tram bypasses foggy sidewalks and stops directly in front of Pier 9.",
        hasOutlet: false,
        pinPos: { top: "68%", left: "24%" },
        svgPos: { x: 82, y: 163 }
      }
    ];
  }

  // Interview scenario destinations: walking time increased to 30 mins!
  return [
    {
      id: "apex",
      name: "Apex Tech Tower (Suite 400)",
      category: "Interview Venue",
      icon: "🏢",
      etaMins: 30, // Realistic substantial walking time so time progresses meaningfully!
      distanceKm: "2.3 km",
      batteryCost: 0.30,
      description: "Final partner interview starts at 9:15 AM. Security glass doors require elevator keypad PIN.",
      isTarget: true,
      hasOutlet: true,
      pinPos: { top: "25%", left: "74%" },
      svgPos: { x: 252, y: 55 }
    },
    {
      id: "cafe",
      name: "Neon Bean Corner Café",
      category: "Coffee & Power",
      icon: "☕",
      etaMins: 11,
      distanceKm: "0.7 km",
      batteryCost: 0.10,
      description: "Customer wall outlets & Wi-Fi. The friendly barista shares their power strip with kind people.",
      hasOutlet: true,
      pinPos: { top: "50%", left: "35%" },
      svgPos: { x: 119, y: 120 }
    },
    {
      id: "metro",
      name: "Central Metro Transit Hub",
      category: "Subway",
      icon: "🚇",
      etaMins: 12,
      distanceKm: "0.8 km",
      batteryCost: 0.08,
      description: "Express Line 2 stops directly beneath Apex Tech Tower. Fast subway transit avoids traffic.",
      hasOutlet: false,
      pinPos: { top: "68%", left: "24%" },
      svgPos: { x: 82, y: 163 }
    },
    {
      id: "kiosk",
      name: "QuickFix Electronics Kiosk",
      category: "Chargers & Gadgets",
      icon: "🔌",
      etaMins: 10,
      distanceKm: "0.6 km",
      batteryCost: 0.09,
      description: "Emergency portable power bank rental and fast charging cables. Open now.",
      hasOutlet: true,
      pinPos: { top: "38%", left: "60%" },
      svgPos: { x: 204, y: 91 }
    }
  ];
}

export const MAP_DESTINATIONS = getMapDestinations('interview');

export const STREET_DILEMMAS: StreetDilemma[] = [
  {
    id: "tourist",
    title: "Commuter Looking Lost",
    desc: "An elderly gentleman holding a paper subway map looks around anxiously near 4th Avenue.",
    icon: "🗺️",
    choices: [
      {
        text: "🤝 Stop and point him toward the Uptown train",
        batteryCost: 0,
        timeCost: 2,
        socialDelta: 25,
        isHuman: true,
        resultToast: "He smiled warmly and thanked you. Your morning anxiety vanished."
      },
      {
        text: "📱 Keep your head down and stare at GPS",
        batteryCost: 0.03,
        timeCost: 0,
        socialDelta: -10,
        isHuman: false,
        resultToast: "You hurried past. Staring at the screen made your neck tense."
      }
    ]
  },
  {
    id: "musician",
    title: "Acoustic Street Guitarist",
    desc: "A street musician is playing a calming acoustic melody outside the plaza under the city lights.",
    icon: "🎸",
    choices: [
      {
        text: "🎶 Pause for 1 minute, smile, and listen to the song",
        batteryCost: 0,
        timeCost: 2,
        socialDelta: 20,
        isHuman: true,
        resultToast: "The music grounded you. You remembered that the world exists outside your screen."
      },
      {
        text: "📱 Check screen battery percentage again",
        batteryCost: 0.02,
        timeCost: 0,
        socialDelta: -5,
        isHuman: false,
        resultToast: "You checked the battery gauge. Still low. Your pulse spiked slightly."
      }
    ]
  },
  {
    id: "barista_wave",
    title: "Corner Bodega Charging Station",
    desc: "A corner shop has a sign: 'Free 2-minute top-up plug with any friendly morning greeting!'",
    icon: "🔌",
    choices: [
      {
        text: "🤝 Greet the shopkeeper warmly & plug in phone (+4%)",
        batteryCost: -4.0,
        timeCost: 3,
        socialDelta: 20,
        isHuman: true,
        resultToast: "Shopkeeper: 'Go get 'em, champion!' Gained +4% battery!"
      },
      {
        text: "🏃 Rush past without speaking to anyone",
        batteryCost: 0.01,
        timeCost: 0,
        socialDelta: -5,
        isHuman: false,
        resultToast: "You kept running, clinging to your dying battery."
      }
    ]
  }
];

export function getCameraScenes(scenarioId: ScenarioId, code: string) {
  if (scenarioId === 'date') {
    return [
      {
        id: 0,
        name: "Starlight Rooftop Hostess Stand",
        desc: "Brass podium and reservation log at the entrance of the rooftop terrace.",
        hasClue: true,
        clueText: `Table 14 Terrace Access PIN: ${code}`,
        photoEmoji: "🍸📋✨"
      },
      {
        id: 1,
        name: "Terrace Fountain & City Lights",
        desc: "Panoramic city overlook. Jordan is visible in an emerald jacket by the fountain.",
        hasClue: true,
        clueText: "Jordan spotted smiling by the fountain wearing green jacket!",
        photoEmoji: "🌃⛲🌹"
      },
      {
        id: 2,
        name: "Velvet Floral Window Display",
        desc: "Window with single stem roses and evening bouquets.",
        hasClue: true,
        clueText: "Single roses available for $4.50 at the flower boutique.",
        photoEmoji: "💐🌹✨"
      },
      {
        id: 3,
        name: "Evening City Street Life",
        desc: "Couples and friends laughing under string lights.",
        hasClue: false,
        clueText: "Real living humans enjoying the evening, unbothered by screen notifications.",
        photoEmoji: "🌆👥🥂"
      }
    ];
  }

  if (scenarioId === 'farewell') {
    return [
      {
        id: 0,
        name: "Pier 9 Slip B-42 Security Gate",
        desc: "Heavy harbor gate turnstile with digital security keypad.",
        hasClue: true,
        clueText: `Pier 9 Slip B-42 Turnstile Gate PIN: ${code}`,
        photoEmoji: "⚓📋✨"
      },
      {
        id: 1,
        name: "Tokyo Freighter Foggy Gangway",
        desc: "Ocean freight vessel preparing for 11:30 PM departure.",
        hasClue: true,
        clueText: "Ship gangway lifts at 11:30 PM sharp at Slip B-42.",
        photoEmoji: "🚢🌊🌃"
      },
      {
        id: 2,
        name: "Historic Lighthouse Bench",
        desc: "Wooden bench overlooking harbor where kids used to skip stones.",
        hasClue: true,
        clueText: "Kindly old night fisherman has a free phone charging bank.",
        photoEmoji: "🏮🪑🌊"
      },
      {
        id: 3,
        name: "Harbor Bodega Warm Window",
        desc: "Steam rising from late-night coffee urns.",
        hasClue: false,
        clueText: "Real people living their lives in the quiet night mist.",
        photoEmoji: "🏪☕✨"
      }
    ];
  }

  return [
    {
      id: 0,
      name: "Apex Tower Lobby Directory",
      desc: "Marble wall directory at the entrance of Apex Tower.",
      hasClue: true,
      clueText: `Suite 400: Apex Executive Partners · Elevator Access PIN: ${code}`,
      photoEmoji: "🏢📋✨"
    },
    {
      id: 1,
      name: "Transit Plaza Subway Map",
      desc: "Wall-mounted subway map showing express Line 2 to Apex Station.",
      hasClue: true,
      clueText: "Metro Line 2 exits directly into Suite 400 elevator bank.",
      photoEmoji: "🚇🗺️📍"
    },
    {
      id: 2,
      name: "Neon Bean Café Outlet Corner",
      desc: "Customer seating table with open power strip.",
      hasClue: true,
      clueText: "Free customer power strip located under the front window bench.",
      photoEmoji: "☕🔌🪑"
    },
    {
      id: 3,
      name: "Morning Sunlight & Commuters",
      desc: "Dozens of people walking in the crisp morning air.",
      hasClue: false,
      clueText: "Real living humans enjoying the morning, unbothered by screen notifications.",
      photoEmoji: "☀️🏙️👥"
    }
  ];
}

export const CAMERA_SCENES = getCameraScenes('interview', '#4829');

export function getIncomingCalls(scenarioId: ScenarioId, code: string): ActiveIncomingCall[] {
  if (scenarioId === 'date') {
    return [
      {
        callerName: "Jordan (Your Date ❤️)",
        callerNumber: "(555) 382-9014",
        avatar: "🌹",
        subtitle: "Starlight Rooftop Lounge",
        dialogueText: `Hey! Just wanted to make sure you found the building okay? The hostess says our table reservation code is ${code}!`,
        codeClue: code,
        responses: [
          {
            text: "Yes, on my way right now! Can't wait to see you!",
            reply: `Jordan: 'Awesome! I'm right by the fountain table with code ${code}. See you in a few!'`,
            batteryCost: 0.03,
            socialDelta: 25,
            revealsCode: true
          },
          {
            text: "Headed upstairs right now, phone is low on battery!",
            reply: "Jordan: 'No problem at all! Can't wait!'",
            batteryCost: 0.02,
            socialDelta: 15
          },
          {
            text: "(Decline call to save 0.04% battery)",
            reply: "Call sent to voicemail to conserve battery.",
            batteryCost: 0,
            socialDelta: -10
          }
        ]
      },
      {
        callerName: "Alex (Best Friend)",
        callerNumber: "(555) 723-8819",
        avatar: "🥂",
        subtitle: "Mobile",
        dialogueText: "Hey! Just calling to say: you look great, you're funny, and Jordan is going to love you. Breathe deep and have fun!",
        responses: [
          {
            text: "Thanks Alex, you're the best friend ever.",
            reply: "Alex: 'Go have an amazing evening! Talk tomorrow!'",
            batteryCost: 0.02,
            socialDelta: 20
          }
        ]
      }
    ];
  }

  if (scenarioId === 'farewell') {
    return [
      {
        callerName: "Leo (Childhood Best Friend 🌊)",
        callerNumber: "(555) 891-2304",
        avatar: "⚓",
        subtitle: "Pier 9 Slip B-42",
        dialogueText: `Hey! The crew is uncoupling the dock lines! Are you close? Security gate keypad code is ${code}!`,
        codeClue: code,
        responses: [
          {
            text: "Sprinting down the dock right now Leo! Hold that gangway!",
            reply: `Leo: 'I will stall them as long as I can! Key code is ${code}. Run!'`,
            batteryCost: 0.03,
            socialDelta: 25,
            revealsCode: true
          },
          {
            text: "Almost at Slip B-42, don't leave without a real hug!",
            reply: "Leo: 'I am right at the ramp. Can't wait to see you!'",
            batteryCost: 0.02,
            socialDelta: 15
          },
          {
            text: "(Decline call to save 0.04% battery)",
            reply: "Call sent to voicemail to conserve battery.",
            batteryCost: 0,
            socialDelta: -10
          }
        ]
      },
      {
        callerName: "Mom ❤️",
        callerNumber: "(555) 723-8819",
        avatar: "👩",
        subtitle: "Mobile",
        dialogueText: "Honey, did you make it to Pier 9 yet? Childhood friendships are priceless. Don't let your phone make you miss this moment!",
        responses: [
          {
            text: "Almost at the harbor gate Mom, love you!",
            reply: "Mom: 'Give him our love! So proud of you for showing up!'",
            batteryCost: 0.02,
            socialDelta: 20
          }
        ]
      }
    ];
  }

  return [
    {
      callerName: "Apex Front Desk (Sarah)",
      callerNumber: "(555) 019-4829",
      avatar: "🏢",
      subtitle: "Apex Tech Tower Visitor Desk",
      dialogueText: "Hi! This is Sarah from Apex Tech Tower front desk. Mr. Sterling asked me to verify if you needed help with the 4th floor security elevator or the code?",
      codeClue: code,
      responses: [
        {
          text: "Yes please! What was the elevator keypad code again?",
          reply: `Sarah: 'It's ${code}! Press the green checkmark right after. See you on the 4th floor!'`,
          batteryCost: 0.03,
          socialDelta: 15,
          revealsCode: true
        },
        {
          text: "I have it written down, headed up right now!",
          reply: "Sarah: 'Wonderful! Mr. Sterling's team is all set in Suite 400.'",
          batteryCost: 0.02,
          socialDelta: 10
        },
        {
          text: "(Decline call to save 0.04% battery)",
          reply: "Call sent to voicemail to conserve battery.",
          batteryCost: 0,
          socialDelta: -10
        }
      ]
    },
    {
      callerName: "Mom ❤️",
      callerNumber: "(555) 723-8819",
      avatar: "👩",
      subtitle: "Mobile",
      dialogueText: "Hey honey! I just wanted to hear your voice before your big morning. Remember: you've worked so hard for this. Take a deep breath!",
      responses: [
        {
          text: "Thanks Mom, your voice gives me so much calm.",
          reply: "Mom: 'You're brilliant, sweetheart. Go knock their socks off! Love you!'",
          batteryCost: 0.03,
          socialDelta: 30
        },
        {
          text: "Love you Mom, phone is at 4% so I have to be fast!",
          reply: "Mom: 'Understood honey! Go get 'em!'",
          batteryCost: 0.02,
          socialDelta: 15
        }
      ]
    }
  ];
}

export const INCOMING_CALLS = getIncomingCalls('interview', '#4829');

export function getSocialPosts(scenarioId: ScenarioId, code: string): SocialPost[] {
  if (scenarioId === 'date') {
    return [
      {
        id: 101,
        author: "Jordan",
        handle: "@jordan_in_the_city",
        avatar: "🌹",
        timeAgo: "3m ago",
        text: `✨ LIVE STORY: "Just got to Starlight Lounge! Sitting by the outdoor fountain in an emerald green jacket. Hope my date is as wonderful in person! [Hostess says table 14 PIN is ${code}]"`,
        mediaBg: "linear-gradient(135deg, #047857, #065f46)",
        mediaEmoji: "🍸🌃⛲",
        likes: 48,
        liked: false,
        isTargetStory: true,
        intelTitle: "Jordan's Live Story",
        intelReward: `Revealed Jordan is by the terrace fountain wearing emerald green! PIN: ${code}`,
        commentsCount: 6
      },
      {
        id: 102,
        author: "modern_dating_truth",
        handle: "@dating_psychology",
        avatar: "🧠",
        timeAgo: "15m",
        text: "🔥 3 First Date Psychological Green Flags: 1. Leaving your phone face-down or in your pocket. 2. Asking open-ended questions. 3. Being comfortable with 5 seconds of silence without checking a screen.",
        mediaBg: "linear-gradient(135deg, #4f46e5, #7c3aed)",
        mediaEmoji: "❤️📱💬",
        likes: 3840,
        liked: false,
        intelTitle: "Dating Psychology Tip",
        intelReward: "Confidence boosted! Remember to keep phone in pocket during dinner.",
        commentsCount: 142
      },
      {
        id: 103,
        author: "city_rooftops_guide",
        handle: "@nightlifeguide",
        avatar: "🍸",
        timeAgo: "25m",
        text: "Starlight Rooftop terrace has a waitlist of 45 minutes tonight unless you have an active reservation code. Guard at the elevator checks PINs strictly.",
        mediaBg: "linear-gradient(135deg, #1e1b4b, #312e81)",
        mediaEmoji: "🌃✨🥂",
        likes: 1205,
        liked: false
      },
      {
        id: 104,
        author: "viral_otter_hugs",
        handle: "@dailywholesome",
        avatar: "🦦",
        timeAgo: "40m",
        text: "Baby sea otter holds hands while drifting to sleep so they don't drift apart. True connection doesn't need Wi-Fi 🥺❤️",
        mediaBg: "linear-gradient(135deg, #059669, #0d9488)",
        mediaEmoji: "🦦🌊❤️",
        likes: 9410,
        liked: false,
        isBait: true
      },
      {
        id: 105,
        author: "overthinking_dating",
        handle: "@single_in_the_city",
        avatar: "🤡",
        timeAgo: "1h",
        text: "Me stalking my date's Instagram from 2017 while walking to dinner on 4% battery instead of just asking them in person:",
        mediaBg: "linear-gradient(135deg, #db2777, #7c3aed)",
        mediaEmoji: "📱💀🕵️",
        likes: 5120,
        liked: false
      }
    ];
  }

  if (scenarioId === 'farewell') {
    return [
      {
        id: 201,
        author: "Leo",
        handle: "@leo_wanders",
        avatar: "⚓",
        timeAgo: "2m ago",
        text: `✨ LIVE STORY: "Final look at the city skyline before boarding the freighter to Tokyo. Slip B-42 gate PIN is ${code}. Real friends show up in real life instead of leaving comments. 45 mins left."`,
        mediaBg: "linear-gradient(135deg, #0369a1, #0c4a6e)",
        mediaEmoji: "🚢🌃🌊",
        likes: 64,
        liked: false,
        isTargetStory: true,
        intelTitle: "Leo's Departure Story",
        intelReward: `Revealed Slip B-42 turnstile PIN: ${code}! Leo is waiting at the ramp.`,
        commentsCount: 18
      },
      {
        id: 202,
        author: "human_connections_lab",
        handle: "@unplugged_psychology",
        avatar: "🧠",
        timeAgo: "10m",
        text: "🚨 The Modern Friendship Illusion: We think sending reels and reacting with flame emojis equals maintaining friendship. Studies show 85% of people feel more isolated despite having 1,000+ followers. Call them. Visit them. Be present.",
        mediaBg: "linear-gradient(135deg, #7c3aed, #4338ca)",
        mediaEmoji: "💔📱👥",
        likes: 4210,
        liked: false,
        intelTitle: "Psychology Insight",
        intelReward: "Remembered that true friendship requires physical presence.",
        commentsCount: 230
      },
      {
        id: 203,
        author: "harbor_authority_live",
        handle: "@city_port_master",
        avatar: "⚓",
        timeAgo: "22m",
        text: "Notice: International departure gates at Pier 9 operate under strict curfew. Slip B-42 automated turnstiles will seal at 11:30 PM sharp for customs clearance.",
        mediaBg: "linear-gradient(135deg, #1e293b, #0f172a)",
        mediaEmoji: "⚓🕒🔒",
        likes: 312,
        liked: false
      },
      {
        id: 204,
        author: "nostalgia_2000s",
        handle: "@before_smartphones",
        avatar: "📼",
        timeAgo: "35m",
        text: "Remember riding bikes until streetlights came on, knocking on your best friend's door, and having three-hour conversations without anyone glancing at a black screen?",
        mediaBg: "linear-gradient(135deg, #b45309, #d97706)",
        mediaEmoji: "🚲🌇🛹",
        likes: 12540,
        liked: false,
        isBait: true
      },
      {
        id: 205,
        author: "viral_otter_hugs",
        handle: "@dailywholesome",
        avatar: "🦦",
        timeAgo: "40m",
        text: "Baby sea otter holds hands while drifting to sleep so they don't drift apart. True connection doesn't need Wi-Fi 🥺❤️",
        mediaBg: "linear-gradient(135deg, #059669, #0d9488)",
        mediaEmoji: "🦦🌊❤️",
        likes: 9410,
        liked: false,
        isBait: true
      }
    ];
  }

  // Interview scenario posts
  return [
    {
      id: 1,
      author: "Apex Tech Insider",
      handle: "@apex_careers_live",
      avatar: "👔",
      timeAgo: "4m ago",
      text: `📢 LIVE STORY: "For candidates interviewing in Suite 400 today: Left elevator bank is secured. Use the right glass gate with elevator PIN ${code}. Mr. Sterling values candidates who speak with human clarity!"`,
      mediaBg: "linear-gradient(135deg, #1e3a8a, #1d4ed8)",
      mediaEmoji: "🏢📄✨",
      likes: 89,
      liked: false,
      isTargetStory: true,
      intelTitle: "Apex Insider Tip",
      intelReward: `Elevator PIN is ${code}! Mr. Sterling values calm, human communication.`,
      commentsCount: 14
    },
    {
      id: 2,
      author: "insider_job_secrets",
      handle: "@techcareers_exposed",
      avatar: "💼",
      timeAgo: "8m",
      text: "🔥 LEAKED: The exact 3 behavioral questions Apex Tech asks in Suite 400! [Tap to read thread]",
      mediaBg: "linear-gradient(135deg, #b91c1c, #991b1b)",
      mediaEmoji: "🚨👔📄",
      likes: 1842,
      liked: false,
      isBait: true,
      intelTitle: "Interview Questions",
      intelReward: "Read question leak! Boosts interview confidence +15.",
      commentsCount: 142
    },
    {
      id: 3,
      author: "maya_designs",
      handle: "@mayacreates",
      avatar: "🎨",
      timeAgo: "12m",
      text: "Just submitted my portfolio project after 48 hours without sleep!! Pray for my soul ☕✨ #design #techinterview",
      mediaBg: "linear-gradient(135deg, #4f46e5, #9333ea)",
      mediaEmoji: "🎨💻☕",
      likes: 342,
      liked: false
    },
    {
      id: 4,
      author: "city_pigeons_daily",
      handle: "@confident_pigeon",
      avatar: "🐦",
      timeAgo: "28m",
      text: "Look at this distinguished gentleman strutting down 5th Avenue like he pays taxes. Absolute city king.",
      mediaBg: "linear-gradient(135deg, #0284c7, #38bdf8)",
      mediaEmoji: "🐦🍞👑",
      likes: 1205,
      liked: false
    },
    {
      id: 5,
      author: "viral_otter_hugs",
      handle: "@dailywholesome",
      avatar: "🦦",
      timeAgo: "40m",
      text: "Baby sea otter refuses to nap without holding hands with his caretaker. 5-second video that will heal your soul 🥺❤️",
      mediaBg: "linear-gradient(135deg, #059669, #0d9488)",
      mediaEmoji: "🦦🌊❤️",
      likes: 9410,
      liked: false,
      isBait: true
    }
  ];
}

export const SOCIAL_POSTS = getSocialPosts('interview', '#4829');

export function getInitialChecklist(scenarioId: ScenarioId): ChecklistItem[] {
  if (scenarioId === 'date') {
    return [
      { id: 1, text: "Reply to Jordan's text", done: false },
      { id: 2, text: "Check route to Starlight Rooftop on Maps", done: false },
      { id: 3, text: "Find Table 14 reservation PIN", done: false },
      { id: 4, text: "Arrive at Starlight Rooftop before 8:30 PM", done: false },
      { id: 5, text: "Put phone away & make real eye contact", done: false }
    ];
  }

  if (scenarioId === 'farewell') {
    return [
      { id: 1, text: "Reply to Leo's farewell text", done: false },
      { id: 2, text: "Check route to Pier 9 on Maps", done: false },
      { id: 3, text: "Find Slip B-42 gate PIN", done: false },
      { id: 4, text: "Reach Pier 9 Gate before 11:30 PM", done: false },
      { id: 5, text: "Give Leo an authentic in-person hug", done: false }
    ];
  }

  return [
    { id: 1, text: "Reply to Mr. Sterling's message", done: false },
    { id: 2, text: "Check route to Apex Tower on Maps", done: false },
    { id: 3, text: "Find elevator security PIN", done: false },
    { id: 4, text: "Arrive at Suite 400 before 9:15 AM", done: false },
    { id: 5, text: "Make at least 1 real Human Connection", done: false }
  ];
}

export const INITIAL_CHECKLIST: ChecklistItem[] = getInitialChecklist('interview');

export function getInitialNotes(scenarioId: ScenarioId, code: string): string {
  if (scenarioId === 'date') {
    return `🌹 FIRST DATE CHEAT SHEET: JORDAN

1. RESERVATION DETAILS:
• Location: Starlight Rooftop Lounge (12th Floor Terrace)
• Table 14 Reservation PIN: ${code}
• Time: 8:30 PM Sharp

2. THINGS JORDAN MENTIONED:
• Favorite hobby: Film photography & rooftop sunsets
• Loves: Authentic conversations, spontaneous humor, people who don't text during dinner
• Dislikes: People who stare at their phone while someone is speaking

3. GOLDEN RULE:
Keep your phone in your pocket. Look them in the eyes. Real human connection happens when screens go black.`;
  }

  if (scenarioId === 'farewell') {
    return `⚓ FAREWELL NOTE: LEO'S TOKYO DEPARTURE

1. HARBOR DETAILS:
• Location: Pier 9 International Terminal (Slip B-42)
• Gate Turnstile PIN: ${code}
• Boarding Cutoff: 11:30 PM Sharp!

2. MEMORIES WITH LEO:
• Best friends since 3rd grade on Elm Street
• Last time we hung out in real life: 14 months ago
• We promised we wouldn't become people who only talk through social media comments

3. PHILOSOPHY:
Screens make distant people seem close, while making the people standing right next to us disappear. Put the phone away. Give your best friend a hug.`;
  }

  return `📝 APEX TECH CANDIDATE CHEAT SHEET

1. SUITE 400 DETAILS:
• Location: 4th Floor, Apex Tower
• Elevator Security Code: ${code}
• Meeting: 9:15 AM Partner Panel with Mr. Sterling

2. CORE TALKING POINTS:
• Passion for resilient, thoughtful systems
• Proven ability to remain calm when systems degrade
• Understanding that technology is a bridge for humans, not a replacement for them

3. REMEMBER:
Look them in the eye. A confident smile and authentic connection speak louder than any phone screen.`;
}

export const INITIAL_NOTES_CONTENT = getInitialNotes('interview', '#4829');

export function getInitialSimState(
  presetId: PhonePresetId = 'iphone18pro', 
  scenarioId: ScenarioId = 'interview',
  customCode?: string
): SimState {
  const modelConfig = PHONE_MODELS.find(p => p.id === presetId) || PHONE_MODELS[0];
  const dynamicCode = customCode || generateRandomSecurityCode();
  const scenario = SCENARIOS.find(s => s.id === scenarioId) || SCENARIOS[0];

  return {
    device: {
      os: modelConfig.os,
      model: modelConfig.name,
      batteryHealth: modelConfig.batteryHealth,
      drainMultiplier: modelConfig.drainMultiplier,
    },
    selectedPhone: presetId,
    currentScenario: scenarioId,
    showScenarioSelector: false,
    showPhoneSelector: false,
    showMissionBriefing: false,
    playerPos: { x: 60, y: 160 },
    interviewArrivedPrompt: false,
    timeIsUpPrompt: false,

    // Hardware & Narrative Complexity
    cpuTemp: 35,
    doorSecurityCode: dynamicCode,
    doorKeypadOpen: false,
    doorCodeEntered: '',
    doorUnlocked: false,
    incomingCallActive: false,
    currentIncomingCall: null,
    activeCallConnected: false,
    transitDilemmaActive: false,
    freeChargingGiven: false,

    // Real moving walk & dilemmas
    isWalkingProgress: false,
    walkingStep: 0,
    activeStreetDilemma: null,
    checklist: getInitialChecklist(scenarioId), // Strictly starts at Task 0/5!

    // Camera & Notes Complexity
    cameraSceneIndex: 0,
    savedPhotos: [],
    userCustomNotes: getInitialNotes(scenarioId, dynamicCode),
    pollVotedIndex: null,
    dialNumber: '',

    dopaminePoints: 0,
    humanMoments: 0,
    screenAddictionScore: 20,
    lastGuiltMessage: null,
    humanMomentsLogged: [],
    digitalTrapsFallenFor: [],
    battery: modelConfig.startingBattery, // Starts < 10% (7.5%, 6.0%, 4.2%, 3.0%)
    maxBattery: 100,
    isCharging: false,
    isDead: false,
    timeMinutes: scenario.startMinutes, // 485 (8:05 AM) or 1185 (7:45 PM)
    targetInterviewTime: scenario.targetMinutes, // 555 (9:15 AM) or 1230 (8:30 PM)
    money: 35.0,
    stress: 20,
    distraction: 10,
    socialConnection: 15,
    settings: {
      lowPowerMode: false,
      brightness: 0.75,
      wifi: true,
      bluetooth: true,
      locationServices: true,
      notifications: true,
      flashlight: false,
      greyscaleMode: false,
      refreshRate60Hz: false,
      backgroundAppRefresh: true,
      airplaneMode: false
    },
    currentLocation: "Transit Station Plaza",
    destination: scenario.targetLocation,
    activeNavigation: false,
    destinationReached: false,
    interviewCompleted: false,
    inventory: ['Transit Pass'],
    appUsage: {
      messages: { minutes: 0, batterySpent: 0, interactions: 0 },
      maps: { minutes: 0, batterySpent: 0, interactions: 0 },
      social: { minutes: 0, batterySpent: 0, interactions: 0 },
      camera: { minutes: 0, batterySpent: 0, interactions: 0 },
      phone: { minutes: 0, batterySpent: 0, interactions: 0 },
      settings: { minutes: 0, batterySpent: 0, interactions: 0 },
      notes: { minutes: 0, batterySpent: 0, interactions: 0 },
      wallet: { minutes: 0, batterySpent: 0, interactions: 0 },
      idle: { minutes: 0, batterySpent: 0, interactions: 0 }
    },
    flags: {
      readNotesBeforeDead: false,
      checkedBossMessage: false,
      repliedToBoss: false,
      askedStrangerForHelp: false,
      befriendedPigeon: false,
      boughtPowerBank: false,
      boughtCoffee: false,
      usedOutletAtCafe: false,
      tookInterviewPhoto: false,
      doomscrolledReelsCount: 0,
      ignoredChargingOpportunity: false,
      turnedOnLowPowerEarly: false,
      lowBatteryWarned20: false,
      lowBatteryWarned10: false,
      lowBatteryWarned5: false
    },
    badges: {
      messages: 2,
      social: 4,
      settings: 0,
      notes: 1,
      phone: 0
    },
    activeApp: null,
    currentView: 'home',
    isControlCenterOpen: false
  };
}

export function formatSimTime(mins: number): string {
  const totalMinutes = Math.floor(mins);
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  const period = h >= 12 ? 'PM' : 'AM';
  const displayH = h % 12 === 0 ? 12 : h % 12;
  const displayM = m < 10 ? `0${m}` : `${m}`;
  return `${displayH}:${displayM} ${period}`;
}

export interface DoomscrollReel {
  id: string;
  author: string;
  handle: string;
  avatar: string;
  text: string;
  mediaBg: string;
  mediaEmoji: string;
  views: string;
  likes: number;
  dopamine: number;
  guiltToast: string;
}

export const VIRAL_DOOMSCROLL_REELS: DoomscrollReel[] = [
  {
    id: "reel-1",
    author: "Brainrot Clips Daily",
    handle: "@infinite_dopamine",
    avatar: "🧠",
    text: "🔥 Guy argues with subway conductor for 4 minutes until they realize they both love vintage synthesizers. (Wait for the beat drop at the end!)",
    mediaBg: "linear-gradient(135deg, #ec4899, #8b5cf6)",
    mediaEmoji: "🎹🚇🕺",
    views: "1.4M",
    likes: 84200,
    dopamine: 20,
    guiltToast: "You watched a 4-minute subway video while your real-world walk timer ticked away."
  },
  {
    id: "reel-2",
    author: "Overthinking Gen-Z",
    handle: "@unplug_pls",
    avatar: "🤡",
    text: "POV: You opened your phone to check what time the destination locks, and now it's 10 minutes later and you're watching a raccoon eat grapes with a fork.",
    mediaBg: "linear-gradient(135deg, #f59e0b, #ef4444)",
    mediaEmoji: "🦝🍇🍴",
    views: "3.2M",
    likes: 194000,
    dopamine: 25,
    guiltToast: "The algorithm served you tailored distraction while your battery drained into red."
  },
  {
    id: "reel-3",
    author: "Silicon Valley Realist",
    handle: "@tech_humor",
    avatar: "💻",
    text: "We spent 50 years putting the entire repository of human wisdom into a pocket slab, only to use it to watch cats get startled by cucumbers.",
    mediaBg: "linear-gradient(135deg, #10b981, #06b6d4)",
    mediaEmoji: "🐱🥒💀",
    views: "890K",
    likes: 62000,
    dopamine: 15,
    guiltToast: "You chuckled at the meme, but lost 3 minutes of battery and precious time."
  },
  {
    id: "reel-4",
    author: "Wholesome Animals Hub",
    handle: "@baby_capybara",
    avatar: "🍊",
    text: "Baby capybara taking a warm citrus bath and closing its eyes in complete serene unplugged bliss. 0 screens. 100% peace.",
    mediaBg: "linear-gradient(135deg, #f97316, #eab308)",
    mediaEmoji: "🍊🐾🛁",
    views: "4.8M",
    likes: 310000,
    dopamine: 30,
    guiltToast: "You felt warmth watching a digital capybara, while neglecting real people waiting for you in real life."
  },
  {
    id: "reel-5",
    author: "Late Night Philosophy",
    handle: "@unfiltered_human",
    avatar: "🌌",
    text: "Your phone has never hugged you back. When you're old, you won't remember a single short-form reel. You'll only remember the people you showed up for.",
    mediaBg: "linear-gradient(135deg, #3b82f6, #1d4ed8)",
    mediaEmoji: "🌌🤝❤️",
    views: "2.1M",
    likes: 142000,
    dopamine: 20,
    guiltToast: "The irony hits hard: reading about presence on a screen while walking past living souls."
  }
];

export function evaluateEnding(state: SimState): EndingResult {
  const isDead = state.isDead || state.battery <= 0;
  const onTime = state.timeMinutes <= state.targetInterviewTime && state.destinationReached;
  const isDate = state.currentScenario === 'date';
  const isFarewell = state.currentScenario === 'farewell';
  const doomscrolled = state.flags.doomscrolledReelsCount >= 2 || state.flags.fomoViralClicked;
  const askedHuman = state.flags.askedStrangerForHelp || state.socialConnection >= 45;
  const usedMoney = state.flags.boughtPowerBank;
  const prepared = state.flags.readNotesBeforeDead || state.flags.turnedOnLowPowerEarly;

  let title = isFarewell ? "MIDNIGHT EMBRACE AT PIER 9" : isDate ? "ROOFTOP REUNION COMPLETED" : "SURVIVED THE MORNING";
  let tag = "MISSION ACCOMPLISHED";
  let badgeIcon = isFarewell ? "⚓" : isDate ? "🥂" : "😅";
  let color = "#38bdf8";
  let narrative = "";
  let philosophicalGuilt = "";
  let humanConnectionVerdict = "";
  let outcome: 'interview_crushed' | 'interview_made_barely' | 'interview_missed' | 'human_enlightened' = 'interview_made_barely';

  if (isDead) {
    if (prepared || askedHuman || state.doorUnlocked) {
      title = isFarewell ? "THE PHONE DIES, FRIENDSHIP SAVED" : isDate ? "THE PHONE DIES, ROMANCE BLOOMS" : "THE PHONE DIES, LIFE CONTINUES";
      tag = "UNPLUGGED RECONNECTION";
      badgeIcon = isFarewell ? "⚓" : isDate ? "🌹" : "🌅";
      color = "#38bdf8";
      narrative = isFarewell
        ? `Your phone went pitch black in the cold mist of Pier 9. Yet because you memorized the turnstile code (${state.doorSecurityCode}) or asked the old harbor fisherman for directions, you sprinted onto Slip B-42 before 11:30 PM. You pulled Leo into a fierce, breathless hug right on the gangway. No selfies. No story posts. Just two childhood friends holding each other with tears in your eyes.`
        : isDate
        ? `Your phone died completely before reaching Table 14. Yet because you remembered the reservation code (${state.doorSecurityCode}) or asked the terrace hostess, you walked up to Jordan with an empty screen and full attention. You spent 2 hours laughing and listening without a single digital interruption.`
        : `Your phone went completely black before reaching the lobby. Yet because you remembered the security code (${state.doorSecurityCode}) or asked the security guard for help, you stepped into Suite 400 on time. You looked into people's eyes instead of downward at a dying piece of glass.`;
      philosophicalGuilt = isFarewell
        ? "For two years, algorithms convinced you that double-tapping someone's photos was friendship. But a real hug on a cold dock proved that human presence cannot be simulated by pixels."
        : "When the battery hit 0%, your initial panic felt like suffocating. But within two minutes, your shoulders dropped. You heard city sounds. You saw a real face smiling at you. You realized your phone wasn't connecting you—it was keeping you from being present.";
      humanConnectionVerdict = isFarewell
        ? "⚓ Lifelong Anchor: Honored real-life friendship over screens."
        : isDate 
        ? "🌟 Authentic Lover: Unplugged and fully present on your first date." 
        : "🌟 Awakened Humanist: The dying phone liberated your attention.";
      outcome = 'human_enlightened';
    } else if (doomscrolled) {
      title = isFarewell ? "THE FOGGY WHISTLE OF REGRET" : isDate ? "STANDUP BY DOOMSCROLL" : "THE DOOMSCROLL COLLAPSE";
      tag = "ALGORITHMIC CAPTIVITY";
      badgeIcon = "💀";
      color = "#ef4444";
      narrative = isFarewell
        ? "You got stuck doomscrolling short-form reels and group chats while walking the docks. The algorithm sucked your final battery and minutes away. When you finally reached Slip B-42 at 11:38 PM, the foghorn echoed across the dark water. The ship had cast off. Leo was gone."
        : isDate
        ? "You got stuck doomscrolling dating memes and viral videos while walking. The algorithm consumed your final 5% battery. By the time you arrived, your phone was dead, you couldn't check Table 14, and Jordan had already left thinking you stood them up."
        : "You opened social media 'just for a quick peek.' The algorithm served you rage-bait, otter clips, and leaked gossip. Your phone consumed its final percentage of battery rendering pixels of people you will never meet. When you looked up, the phone was dead and the interview had started without you.";
      philosophicalGuilt = isFarewell
        ? "You traded saying goodbye to your oldest childhood friend for 15-second stranger videos. You will never get that moment back."
        : isDate
        ? "You traded a real-life romance with a living person for 15-second algorithmic videos. Screens stole your chance at love."
        : "You traded your real-life career breakthrough for 4 cat videos and an inflammatory comment section. A dozen living, breathing humans walked past you on the sidewalk, ready to help—but you chose to stare at glass until the lights went out.";
      humanConnectionVerdict = "💔 Total Digital Capture: Screen addiction cost you what mattered most.";
      outcome = 'interview_missed';
    } else {
      title = "THE CHAOTIC COLLAPSE";
      tag = "TOTAL VOLTAGE MELTDOWN";
      badgeIcon = "🤡";
      color = "#f59e0b";
      narrative = "The phone died at an inopportune moment. Without offline notes or the courage to ask someone for help, you stood outside an unmarked building paralyzed by the sudden silence.";
      philosophicalGuilt = "We have become so dependent on digital crutches that taking away a 6-inch slab leaves us unable to find an address in our own city. Look up next time.";
      humanConnectionVerdict = "⚠️ Helpless Without Screen: Human instinct atrophied.";
      outcome = 'interview_missed';
    }
  } else if (onTime) {
    if (state.battery <= 1.5) {
      title = isFarewell ? "THE 1% MIDNIGHT SPRINT" : isDate ? "THE 1% DATE SURVIVOR" : "THE 1% CLUTCH LEGEND";
      tag = "STEEL NERVES";
      badgeIcon = "⚡";
      color = "#eab308";
      narrative = isFarewell
        ? "You reached Slip B-42 with 1% battery pulsing crimson. You typed the gate code, ran down the ramp, and embraced Leo right before the final gangway was raised into the ship."
        : isDate
        ? "You reached Table 14 with 1% battery pulsing crimson. You showed the reservation code, sat down with Jordan, and immediately put the dead phone away in your coat to focus 100% on them."
        : "You arrived at Suite 400 with literally 1% battery pulsing crimson on your screen. You unlocked the security door, shook the interviewer's hand, plugged your device into the conference table outlet, and smiled like you had it under control the whole time.";
      philosophicalGuilt = "You pulled it off by a hair. But ask yourself: how much adrenaline did you waste obsessing over a battery gauge instead of enjoying the world around you?";
      humanConnectionVerdict = "⚖️ Tightrope Walker: Survived, but barely present.";
      outcome = 'interview_made_barely';
    } else if (usedMoney) {
      title = "THE EXPENSIVE SURVIVOR";
      tag = "PAY-TO-WIN RESCUE";
      badgeIcon = "💸";
      color = "#10b981";
      narrative = "You threw financial caution to the wind and bought an emergency power bank at the kiosk. Your phone stayed alive, but you spent $24 because you were afraid of being without a screen for 30 minutes.";
      philosophicalGuilt = "Money solved what 30 seconds of human communication could have solved for free.";
      humanConnectionVerdict = "💳 Transactional Survival: Paid money to avoid asking a stranger.";
      outcome = 'interview_crushed';
    } else if (askedHuman || state.freeChargingGiven) {
      title = isFarewell ? "THE ANCHOR OF TRUE FRIENDSHIP" : isDate ? "THE REAL ROMANTIC MASTER" : "THE HUMAN CONNECTION MASTER";
      tag = "COMMUNITY TRIUMPH";
      badgeIcon = "🤝";
      color = "#22c55e";
      narrative = isFarewell
        ? "Instead of staring at a glowing phone in the cold, you spoke to the night fisherman, asked the dock cashier for help, and gave your lifelong friend the sendoff they deserved."
        : isDate
        ? "Instead of burying your nose in a dying phone, you bought Jordan a single red rose, chatted with the terrace hostess, and arrived with open eyes and a warm smile. The date was magical."
        : "Instead of burning battery staring down at GPS recalculations, you talked to real commuters, got friendly advice from the barista, and reached your goal through good old-fashioned human interaction.";
      philosophicalGuilt = "You proved the fundamental truth: human beings are naturally helpful and cooperative. You didn't need 5G satellites—you just needed a friendly voice and open eyes.";
      humanConnectionVerdict = "❤️ Master of Real Life: High Human Connection score.";
      outcome = 'human_enlightened';
    } else {
      title = "THE METHODICAL SURVIVOR";
      tag = "TACTICAL MASTERCLASS";
      badgeIcon = "🧠";
      color = "#22c55e";
      narrative = "You activated Low Power Mode, turned down brightness, walked with purpose, and replied with disciplined texts. You arrived with juice to spare.";
      philosophicalGuilt = "You mastered the machine instead of letting the machine master you.";
      humanConnectionVerdict = "🎯 Balanced Digital Citizen: Disciplined device boundaries.";
      outcome = 'interview_crushed';
    }
  } else {
    title = isFarewell ? "THE TARDY FAREWELL" : isDate ? "THE TARDY FIRST DATE" : "THE MISSED WINDOW";
    tag = "TARDY ARRIVAL";
    badgeIcon = "⏳";
    color = "#f59e0b";
    narrative = isFarewell
      ? "You reached Slip B-42, but the clock read past 11:30 PM. The customs gate was bolted shut, and the ship was already steaming away into the ocean fog."
      : isDate
      ? "You reached Starlight Lounge, but it was past 8:30 PM. The hostess gave Table 14 to someone else, and Jordan was standing by the coat check looking disappointed."
      : "You reached the building, but you clocked in past 9:15 AM. You spent too much time toggling between apps and wandering without committing to a transit route.";
    philosophicalGuilt = "The phone gives the illusion that we have endless time, while quietly siphoning away every minute until opportunity passes us by.";
    humanConnectionVerdict = "⏱️ Time Slippage: Absorbed by the screen.";
    outcome = 'interview_missed';
  }

  return {
    title,
    tag,
    badgeIcon,
    color,
    narrative,
    philosophicalGuilt,
    humanConnectionVerdict,
    metrics: {
      batteryLeft: Math.round(state.battery * 10) / 10,
      socialConnectionScore: state.socialConnection,
      screenAddictionScore: state.screenAddictionScore,
      moneySpent: Math.round((35.0 - state.money) * 100) / 100,
      survivalOutcome: outcome
    }
  };
}
