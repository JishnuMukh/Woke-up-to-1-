export type DeviceOS = 'ios' | 'android' | 'generic';

export type PhonePresetId = 'iphone18pro' | 'android2017' | 'iphone7' | 'foldable';

export type ScenarioId = 'interview' | 'date' | 'farewell';

export interface ScenarioConfig {
  id: ScenarioId;
  title: string;
  subtitle: string;
  tag: string;
  desc: string;
  icon: string;
  targetName: string;
  targetLocation: string;
  targetTimeFormatted: string;
  startMinutes: number; // 485 = 8:05 AM, 1185 = 7:45 PM
  targetMinutes: number; // 555 = 9:15 AM, 1230 = 8:30 PM
  contactName: string;
  contactAvatar: string;
  contactRole: string;
  codeContext: string; // e.g. "Elevator Security PIN" or "Table Reservation Code"
  initialBriefing: string;
}

export interface PhoneModelConfig {
  id: PhonePresetId;
  name: string;
  tag: string;
  desc: string;
  os: DeviceOS;
  batteryHealth: number;
  drainMultiplier: number;
  startingBattery: number;
  bezelStyle: 'dynamic_island' | 'chin_bezel' | 'classic_home_button' | 'fold_crease';
  perk: string;
  drawback: string;
  chassisColor: string;
  accentColor: string;
  hasCrackOverlay?: boolean;
}

export type ScreenView = 
  | 'lock'
  | 'home'
  | 'app'
  | 'shutdown'
  | 'recap';

export type AppId = 
  | 'messages'
  | 'maps'
  | 'social'
  | 'settings'
  | 'camera'
  | 'notes'
  | 'phone'
  | 'wallet';

export interface DeviceSettings {
  lowPowerMode: boolean;
  brightness: number; // 0.15 to 1.0
  wifi: boolean;
  bluetooth: boolean;
  locationServices: boolean;
  notifications: boolean;
  flashlight: boolean;
  greyscaleMode: boolean;
  refreshRate60Hz: boolean;
  backgroundAppRefresh: boolean;
  airplaneMode: boolean;
}

export interface AppUsageMetric {
  minutes: number;
  batterySpent: number;
  interactions: number;
}

export interface GameFlags {
  readNotesBeforeDead: boolean;
  checkedBossMessage: boolean;
  repliedToBoss: boolean;
  repliedPoliteToBoss?: boolean;
  repliedLowBatteryToBoss?: boolean;
  repliedStuckToBoss?: boolean;
  askedStrangerForHelp: boolean;
  befriendedPigeon: boolean;
  boughtPowerBank: boolean;
  boughtCoffee: boolean;
  usedOutletAtCafe: boolean;
  tookInterviewPhoto: boolean;
  doomscrolledReelsCount: number;
  ignoredChargingOpportunity: boolean;
  turnedOnLowPowerEarly: boolean;
  lowBatteryWarned20: boolean;
  lowBatteryWarned10: boolean;
  lowBatteryWarned5: boolean;
  bossMessageFired?: boolean;
  cafeChargingSpotted?: boolean;
  mayaPulseFired?: boolean;
  momMessageFired?: boolean;
  timeWarning15?: boolean;
  timeWarning5?: boolean;
  overheated?: boolean;
  fomoViralClicked?: boolean;
  robocallFired?: boolean;
  receptionistCallFired?: boolean;
  momCallFired?: boolean;
  transitDelayEncountered?: boolean;
  scannedLobbyDirectory?: boolean;
}

export interface StreetDilemma {
  id: string;
  title: string;
  desc: string;
  icon: string;
  choices: {
    text: string;
    batteryCost: number;
    timeCost: number;
    socialDelta: number;
    isHuman: boolean;
    resultToast: string;
  }[];
}

export interface ActiveIncomingCall {
  callerName: string;
  callerNumber: string;
  avatar: string;
  subtitle: string;
  dialogueText: string;
  codeClue?: string;
  responses: {
    text: string;
    reply: string;
    batteryCost: number;
    socialDelta: number;
    revealsCode?: boolean;
  }[];
}

export interface SimState {
  device: {
    os: DeviceOS;
    model: string;
    batteryHealth: number;
    drainMultiplier: number;
  };
  selectedPhone: PhonePresetId;
  currentScenario: ScenarioId;
  showScenarioSelector: boolean;
  showPhoneSelector: boolean;
  showMissionBriefing: boolean;
  playerPos: { x: number; y: number };
  interviewArrivedPrompt: boolean;
  timeIsUpPrompt: boolean;
  
  // Complexity Mechanics
  cpuTemp: number; // in Celsius: 34 to 52°C
  doorSecurityCode: string; // Dynamic random 4-digit code e.g. "#7392"
  doorKeypadOpen: boolean; // Security keypad at Suite 400
  doorCodeEntered: string;
  doorUnlocked: boolean;
  incomingCallActive: boolean;
  currentIncomingCall: ActiveIncomingCall | null;
  activeCallConnected: boolean;
  transitDilemmaActive: boolean;
  freeChargingGiven: boolean;

  // Real moving walk & dilemmas
  isWalkingProgress: boolean;
  walkingStep: number;
  activeStreetDilemma: StreetDilemma | null;
  checklist: ChecklistItem[];

  // Camera & Notes Complexity
  cameraSceneIndex: number;
  savedPhotos: { id: number; sceneName: string; clueText?: string; time: string }[];
  userCustomNotes: string;
  pollVotedIndex: number | null;
  dialNumber: string;

  dopaminePoints: number;
  humanMoments: number;
  screenAddictionScore: number; // 0 to 100
  lastGuiltMessage: string | null;
  humanMomentsLogged: string[];
  digitalTrapsFallenFor: string[];
  battery: number; // Starts < 10% (e.g. 7.5%, 6%, 4%, 3%)
  maxBattery: number;
  isCharging: boolean;
  isDead: boolean;
  timeMinutes: number; // minutes since midnight (485 = 8:05 AM)
  targetInterviewTime: number; // 555 = 9:15 AM
  money: number;
  stress: number; // 0-100
  distraction: number; // 0-100
  socialConnection: number; // 0-100
  settings: DeviceSettings;
  currentLocation: string;
  destination: string;
  activeNavigation: boolean;
  destinationReached: boolean;
  interviewCompleted: boolean;
  inventory: string[];
  appUsage: Record<AppId | 'idle', AppUsageMetric>;
  flags: GameFlags;
  badges: Record<string, number>;
  activeApp: AppId | null;
  currentView: ScreenView;
  isControlCenterOpen: boolean;
}

export interface MessageReply {
  text: string;
  batteryCost: number;
  timeCost: number;
  stressDelta: number;
  flag?: keyof GameFlags;
  responseDelay?: number;
  response?: string;
}

export interface ChatMessage {
  sender: 'me' | 'them';
  text: string;
  hasAddress?: boolean;
  addressText?: string;
  mapsTarget?: string;
}

export interface ChatThread {
  id: string;
  name: string;
  avatar: string;
  subtitle: string;
  unread: boolean;
  messages: ChatMessage[];
  replies: MessageReply[];
}

export interface MapDestination {
  id: string;
  name: string;
  category: string;
  icon: string;
  etaMins: number;
  distanceKm: string;
  batteryCost: number;
  description: string;
  isTarget?: boolean;
  hasOutlet?: boolean;
  pinPos: { top: string; left: string };
  svgPos: { x: number; y: number };
}

export interface SocialPost {
  id: number;
  author: string;
  handle: string;
  avatar: string;
  timeAgo: string;
  text: string;
  mediaBg?: string;
  mediaEmoji?: string;
  likes: number;
  liked: boolean;
  isBait?: boolean;
  isTargetStory?: boolean;
  intelTitle?: string;
  intelReward?: string;
  commentsCount?: number;
  comments?: { user: string; text: string }[];
}

export interface ChecklistItem {
  id: number;
  text: string;
  done: boolean;
}

export interface EndingResult {
  title: string;
  tag: string;
  color: string;
  badgeIcon: string;
  narrative: string;
  philosophicalGuilt: string;
  humanConnectionVerdict: string;
  metrics: {
    batteryLeft: number;
    socialConnectionScore: number;
    screenAddictionScore: number;
    moneySpent: number;
    survivalOutcome: 'interview_crushed' | 'interview_made_barely' | 'interview_missed' | 'human_enlightened';
  };
}
