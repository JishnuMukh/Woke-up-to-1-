/**
 * Web Audio API synthesizer for tactile feedback, tones, alerts and shutter
 */

let audioCtx: AudioContext | null = null;
let isMuted = false;

export function setAudioMuted(muted: boolean) {
  isMuted = muted;
}

export function getAudioMuted(): boolean {
  return isMuted;
}

export function initAudio() {
  if (isMuted) return;
  if (!audioCtx) {
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
        if (audioCtx.state === 'suspended') {
          audioCtx.resume();
        }
      }
    } catch {
      // AudioContext unavailable
    }
  } else if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
}

export function playBeep(freq = 600, duration = 0.1, type: OscillatorType = 'sine', volume = 0.08) {
  if (isMuted) return;
  initAudio();
  if (!audioCtx) return;
  try {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

    gain.gain.setValueAtTime(volume, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch {
    // Ignore audio playback errors
  }
}

export function playTap() {
  playBeep(920, 0.04, 'triangle', 0.05);
}

export function playNotificationChime() {
  if (isMuted) return;
  const notes = [659.25, 880]; // E5, A5
  notes.forEach((freq, idx) => {
    setTimeout(() => playBeep(freq, 0.12, 'sine', 0.09), idx * 90);
  });
}

export function playMessageSend() {
  if (isMuted) return;
  const notes = [587.33, 880]; // D5, A5
  notes.forEach((freq, idx) => {
    setTimeout(() => playBeep(freq, 0.08, 'sine', 0.08), idx * 60);
  });
}

export function playCameraShutter() {
  if (isMuted) return;
  initAudio();
  if (!audioCtx) return;
  try {
    const bufferSize = Math.floor(audioCtx.sampleRate * 0.06);
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const noise = audioCtx.createBufferSource();
    noise.buffer = buffer;
    const filter = audioCtx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 1200;
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.06);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(audioCtx.destination);

    noise.start();
  } catch {
    playBeep(1200, 0.06, 'triangle', 0.1);
  }
}

export function playDTMF(digit: string) {
  if (isMuted) return;
  initAudio();
  if (!audioCtx) return;
  try {
    const dtmfMap: Record<string, [number, number]> = {
      '1': [697, 1209], '2': [697, 1336], '3': [697, 1477],
      '4': [770, 1209], '5': [770, 1336], '6': [770, 1477],
      '7': [852, 1209], '8': [852, 1336], '9': [852, 1477],
      '*': [941, 1209], '0': [941, 1336], '#': [941, 1477]
    };
    const freqs = dtmfMap[digit] || [697, 1209];
    const duration = 0.12;

    freqs.forEach(freq => {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    });
  } catch {}
}

export function playRingtone() {
  if (isMuted) return;
  const freqs = [784, 880, 784, 659];
  freqs.forEach((freq, idx) => {
    setTimeout(() => playBeep(freq, 0.15, 'sine', 0.08), idx * 160);
  });
}

export function playLowBatteryWarning() {
  if (isMuted) return;
  playBeep(440, 0.14, 'sawtooth', 0.1);
  setTimeout(() => playBeep(330, 0.22, 'sawtooth', 0.1), 160);
}

export function playPlugInChime() {
  if (isMuted) return;
  const notes = [440, 554.37, 659.25]; // A major
  notes.forEach((freq, idx) => {
    setTimeout(() => playBeep(freq, 0.15, 'sine', 0.09), idx * 80);
  });
}

export function playPhoneDeath() {
  if (isMuted) return;
  const notes = [440, 392, 349, 261];
  notes.forEach((freq, idx) => {
    setTimeout(() => playBeep(freq, 0.25, 'sawtooth', 0.1), idx * 110);
  });
}

export function playVictoryChime() {
  if (isMuted) return;
  const notes = [440, 554.37, 659.25, 880];
  notes.forEach((freq, idx) => {
    setTimeout(() => playBeep(freq, 0.25, 'triangle', 0.09), idx * 100);
  });
}

export function playSocialBoost() {
  if (isMuted) return;
  const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
  notes.forEach((freq, idx) => {
    setTimeout(() => playBeep(freq, 0.1, 'sine', 0.08), idx * 70);
  });
}

export function playDopamineChime() {
  if (isMuted) return;
  const notes = [587.33, 739.99, 880, 1174.66]; // D5, F#5, A5, D6 - uplifting dopamine chime
  notes.forEach((freq, idx) => {
    setTimeout(() => playBeep(freq, 0.08, 'triangle', 0.09), idx * 50);
  });
}

export function playHeartbeat() {
  if (isMuted) return;
  initAudio();
  if (!audioCtx) return;
  try {
    // Double thump (Lub-dub)
    const playThump = (timeOffset: number, pitch: number) => {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(pitch, audioCtx.currentTime + timeOffset);
      osc.frequency.exponentialRampToValueAtTime(35, audioCtx.currentTime + timeOffset + 0.12);

      gain.gain.setValueAtTime(0.18, audioCtx.currentTime + timeOffset);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + timeOffset + 0.14);

      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(audioCtx.currentTime + timeOffset);
      osc.stop(audioCtx.currentTime + timeOffset + 0.15);
    };

    playThump(0, 75);
    playThump(0.12, 65);
  } catch {
    // Ignore audio errors
  }
}

export function playPanicAlarm() {
  if (isMuted) return;
  initAudio();
  if (!audioCtx) return;
  try {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(800, audioCtx.currentTime);
    osc.frequency.linearRampToValueAtTime(450, audioCtx.currentTime + 0.2);

    gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.22);

    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.25);
  } catch {}
}

export function playGlitchStatic() {
  if (isMuted) return;
  initAudio();
  if (!audioCtx) return;
  try {
    const bufferSize = Math.floor(audioCtx.sampleRate * 0.08);
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.4;
    }
    const noise = audioCtx.createBufferSource();
    noise.buffer = buffer;
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.08);
    noise.connect(gain);
    gain.connect(audioCtx.destination);
    noise.start();
  } catch {}
}

