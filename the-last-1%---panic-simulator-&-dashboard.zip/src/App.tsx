import React, { useState, useEffect, useRef } from 'react';
import { SimState, AppId, PhonePresetId } from './types';
import { getInitialSimState, PHONE_MODELS } from './data/initialData';
import { PhoneSimulator } from './components/PhoneSimulator';
import { DashboardInspector } from './components/DashboardInspector';
import { PhoneSelectorModal } from './components/PhoneSelectorModal';
import { MissionBriefingModal } from './components/MissionBriefingModal';
import * as Sound from './utils/audio';
import { Volume2, VolumeX, RotateCcw, Smartphone, LayoutDashboard, Target, HelpCircle } from 'lucide-react';

export default function App() {
  const [state, setState] = useState<SimState>(() => {
    const initial = getInitialSimState('iphone18pro');
    return { ...initial, showPhoneSelector: true };
  });
  const [activeNotification, setActiveNotification] = useState<{ title: string; message: string; app?: AppId } | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [viewMode, setViewMode] = useState<'split' | 'phone'>('split');
  const [activeModal, setActiveModal] = useState<'none' | 'anatomy'>('none');
  const notifTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Trigger Notification through Dynamic Island
  const triggerNotification = (title: string, message: string, app?: AppId) => {
    Sound.playNotificationChime();
    setActiveNotification({ title, message, app });

    if (notifTimeoutRef.current) {
      clearTimeout(notifTimeoutRef.current);
    }
    notifTimeoutRef.current = setTimeout(() => {
      setActiveNotification(null);
    }, 4500);

    if (app) {
      setState(prev => ({
        ...prev,
        badges: {
          ...prev.badges,
          [app]: (prev.badges[app] || 0) + 1
        }
      }));
    }
  };

  const dismissNotification = () => {
    setActiveNotification(null);
    if (notifTimeoutRef.current) {
      clearTimeout(notifTimeoutRef.current);
    }
  };

  // Sound toggle
  const toggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    Sound.setAudioMuted(nextMuted);
    if (!nextMuted) {
      Sound.playTap();
    }
  };

  // Handle phone model change -> immediately opens Mission Briefing so user knows what to do!
  const handleSelectPhone = (phoneId: PhonePresetId) => {
    const fresh = getInitialSimState(phoneId);
    setState({
      ...fresh,
      showPhoneSelector: false,
      showMissionBriefing: true
    });
  };

  const currentPhoneConfig = PHONE_MODELS.find(p => p.id === state.selectedPhone) || PHONE_MODELS[0];

  // Passive background loop: clock & idle energy
  useEffect(() => {
    const interval = setInterval(() => {
      setState(prev => {
        if (prev.isDead || prev.showPhoneSelector || prev.showMissionBriefing || prev.currentView === 'recap') return prev;

        // Gentle idle drain tuned so software interactions decrease less in low battery
        let drain = 0.008 * prev.device.drainMultiplier;
        if (prev.settings.lowPowerMode) drain *= 0.5;
        if (prev.settings.greyscaleMode) drain *= 0.7;
        if (prev.settings.refreshRate60Hz) drain *= 0.8;
        if (!prev.settings.backgroundAppRefresh) drain *= 0.75;
        if (prev.settings.flashlight) drain *= 1.3;
        if (prev.activeNavigation) drain += 0.025;

        const nextBattery = Math.max(0, Math.round((prev.battery - drain) * 100) / 100);
        const isDead = nextBattery <= 0;
        const nextTime = Math.round((prev.timeMinutes + 0.2) * 10) / 10;

        if (isDead && !prev.isDead) {
          Sound.playPhoneDeath();
          return {
            ...prev,
            battery: 0,
            isDead: true,
            currentView: 'shutdown'
          };
        }

        // Automatic arrival at 9:15 AM deadline
        if (nextTime >= 555 && !prev.destinationReached && !prev.flags.timeWarning5) {
          return {
            ...prev,
            battery: nextBattery,
            timeMinutes: 555,
            currentView: 'recap',
            flags: { ...prev.flags, timeWarning5: true }
          };
        }

        // Dynamic event: Receptionist Sarah rings at 8:08 AM (488 mins)
        if (nextTime >= 488 && !prev.flags.receptionistCallFired && !prev.incomingCallActive) {
          Sound.playRingtone();
          return {
            ...prev,
            battery: nextBattery,
            timeMinutes: nextTime,
            incomingCallActive: true,
            currentIncomingCall: {
              callerName: "Apex Front Desk (Sarah)",
              callerNumber: "(555) 019-4829",
              avatar: "🏢",
              subtitle: "Apex Tech Tower Visitor Desk",
              dialogueText: "Hi! This is Sarah from Apex Tech Tower front desk. Mr. Sterling asked me to check if you needed help with the 4th floor security elevator or the door code?",
              codeClue: prev.doorSecurityCode,
              responses: [
                {
                  text: "Yes please! What was the elevator keypad code again?",
                  reply: `Sarah: 'It's ${prev.doorSecurityCode}! Press the green checkmark right after. See you on the 4th floor!'`,
                  batteryCost: 0.02,
                  socialDelta: 15,
                  revealsCode: true
                },
                {
                  text: "I have it noted down, headed up right now!",
                  reply: "Sarah: 'Wonderful! Mr. Sterling's team is all set in Suite 400.'",
                  batteryCost: 0.01,
                  socialDelta: 10
                }
              ]
            },
            flags: { ...prev.flags, receptionistCallFired: true }
          };
        }

        // Dynamic event: Mom calls at 8:12 AM (492 mins)
        if (nextTime >= 492 && !prev.flags.momCallFired && !prev.incomingCallActive) {
          Sound.playRingtone();
          return {
            ...prev,
            battery: nextBattery,
            timeMinutes: nextTime,
            incomingCallActive: true,
            currentIncomingCall: {
              callerName: "Mom ❤️",
              callerNumber: "(555) 723-8819",
              avatar: "👩",
              subtitle: "Mobile",
              dialogueText: "Hey honey! I just wanted to hear your voice before your big morning. Remember: you've worked so hard for this. Take a deep breath!",
              responses: [
                {
                  text: "Thanks Mom, your voice gives me so much calm.",
                  reply: "Mom: 'You're brilliant, sweetheart. Go knock their socks off! Love you!'",
                  batteryCost: 0.02,
                  socialDelta: 25
                },
                {
                  text: "Love you Mom, phone is low on battery so I have to be fast!",
                  reply: "Mom: 'Understood honey! Go get 'em!'",
                  batteryCost: 0.01,
                  socialDelta: 15
                }
              ]
            },
            flags: { ...prev.flags, momCallFired: true }
          };
        }

        return {
          ...prev,
          battery: nextBattery,
          isDead,
          timeMinutes: nextTime,
          currentView: isDead ? 'shutdown' : prev.currentView
        };
      });
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#060b07] text-neutral-100 flex flex-col relative overflow-x-hidden">
      
      {/* Enchanted Grove ambient fireflies & backdrop */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute -top-24 right-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/3 w-[500px] h-[350px] bg-emerald-950/20 rounded-full blur-3xl" />
        
        {/* Animated Firefly particles */}
        <div className="firefly-particle bg-amber-400 shadow-[0_0_8px_#fbbf24]" style={{ left: '12%', top: '45%', animationDuration: '9s' }} />
        <div className="firefly-particle bg-emerald-400 shadow-[0_0_8px_#34d399]" style={{ left: '25%', top: '65%', animationDuration: '13s', animationDelay: '1s' }} />
        <div className="firefly-particle bg-amber-300 shadow-[0_0_8px_#fde047]" style={{ left: '78%', top: '55%', animationDuration: '10s', animationDelay: '2s' }} />
        <div className="firefly-particle bg-emerald-300 shadow-[0_0_8px_#6ee7b7]" style={{ left: '88%', top: '70%', animationDuration: '14s', animationDelay: '3s' }} />
        <div className="firefly-particle bg-amber-400 shadow-[0_0_8px_#fbbf24]" style={{ left: '42%', top: '75%', animationDuration: '11s', animationDelay: '1.5s' }} />
      </div>

      {/* Top Bar Contract (Strict 3-Zone Architecture) */}
      <header className="relative z-50 flex items-center justify-between px-6 py-4 border-b border-emerald-500/15 bg-neutral-950/80 backdrop-blur-xl">
        {/* Zone 1: Single text wordmark */}
        <div className="flex items-center gap-2">
          <a href="/" className="text-base font-bold tracking-tight text-white hover:text-emerald-400 transition-colors">
            The Last 1% Panic Simulator
          </a>
        </div>

        {/* Zone 2: 4-6 Clean navigation links */}
        <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-neutral-400">
          <button 
            onClick={() => {
              Sound.playTap();
              setState(prev => ({ ...prev, showMissionBriefing: true }));
            }}
            className="text-amber-400 hover:text-amber-300 transition-colors cursor-pointer flex items-center gap-1 font-bold"
          >
            <Target className="w-3.5 h-3.5" />
            <span>Mission Tasks</span>
          </button>
          <button 
            onClick={() => {
              Sound.playTap();
              setState(prev => ({ ...prev, showPhoneSelector: true }));
            }}
            className="text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer flex items-center gap-1 font-bold"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Choose Phone</span>
          </button>
          <button 
            onClick={() => {
              Sound.playTap();
              setState(prev => ({ ...prev, currentView: 'home', activeApp: null, isControlCenterOpen: false }));
            }}
            className="hover:text-emerald-400 transition-colors cursor-pointer"
          >
            Home Dashboard
          </button>
          <button 
            onClick={() => {
              Sound.playTap();
              setState(prev => ({ ...prev, currentView: 'app', activeApp: 'maps', isControlCenterOpen: false }));
            }}
            className="hover:text-emerald-400 transition-colors cursor-pointer"
          >
            Maps &amp; GPS
          </button>
          <button 
            onClick={() => {
              Sound.playTap();
              setState(prev => ({ ...prev, currentView: 'recap', isControlCenterOpen: false }));
            }}
            className="hover:text-emerald-400 transition-colors cursor-pointer"
          >
            Story Ending
          </button>
          <button 
            onClick={() => {
              Sound.playTap();
              setActiveModal('anatomy');
            }}
            className="hover:text-emerald-400 transition-colors cursor-pointer"
          >
            Layout Anatomy
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          {/* View toggle (desktop) */}
          <div className="hidden sm:flex items-center bg-white/5 border border-white/10 rounded-lg p-0.5 text-xs font-medium">
            <button
              onClick={() => {
                Sound.playTap();
                setViewMode('split');
              }}
              className={`px-2.5 py-1 rounded-md flex items-center gap-1 transition-all cursor-pointer ${
                viewMode === 'split' ? 'bg-emerald-500/20 text-emerald-300 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
              title="Split View: Phone Simulator + Dashboard Inspector"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>Inspector</span>
            </button>
            <button
              onClick={() => {
                Sound.playTap();
                setViewMode('phone');
              }}
              className={`px-2.5 py-1 rounded-md flex items-center gap-1 transition-all cursor-pointer ${
                viewMode === 'phone' ? 'bg-emerald-500/20 text-emerald-300 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
              title="Focused Phone Simulator Only"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Phone</span>
            </button>
          </div>

          {/* Sound toggle */}
          <button
            onClick={toggleMute}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
            title={isMuted ? "Unmute Audio" : "Mute Audio"}
            aria-label="Toggle Sound"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-neutral-500" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Reset Simulation */}
          <button
            onClick={() => {
              Sound.playTap();
              setState({ ...getInitialSimState(state.selectedPhone), showPhoneSelector: true });
              dismissNotification();
            }}
            className="px-3 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset</span>
          </button>
        </div>
      </header>

      {/* Main Workspace Viewport */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8 flex flex-col justify-center">
        {viewMode === 'split' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left/Center Column: Interactive Smartphone Device */}
            <div className="lg:col-span-5 xl:col-span-5 flex flex-col items-center">
              <PhoneSimulator
                state={state}
                onUpdateState={setState}
                onTriggerNotification={triggerNotification}
                activeNotification={activeNotification}
                onDismissNotification={dismissNotification}
                onOpenPhoneSelector={() => setState(prev => ({ ...prev, showPhoneSelector: true }))}
                onOpenBriefing={() => setState(prev => ({ ...prev, showMissionBriefing: true }))}
              />
              <div className="mt-2 text-center text-xs text-neutral-400">
                Interactive Smartphone · Tap status bar for Quick Settings · Click home bar to exit apps
              </div>
            </div>

            {/* Right Column: Dashboard Inspector & Layout Previews */}
            <div className="lg:col-span-7 xl:col-span-7">
              <DashboardInspector
                state={state}
                onUpdateState={setState}
                onTriggerNotification={triggerNotification}
                onOpenPhoneSelector={() => setState(prev => ({ ...prev, showPhoneSelector: true }))}
                onOpenBriefing={() => setState(prev => ({ ...prev, showMissionBriefing: true }))}
              />
            </div>
          </div>
        ) : (
          /* Focused Phone Only View */
          <div className="flex flex-col items-center justify-center py-2">
            <PhoneSimulator
              state={state}
              onUpdateState={setState}
              onTriggerNotification={triggerNotification}
              activeNotification={activeNotification}
              onDismissNotification={dismissNotification}
              onOpenPhoneSelector={() => setState(prev => ({ ...prev, showPhoneSelector: true }))}
              onOpenBriefing={() => setState(prev => ({ ...prev, showMissionBriefing: true }))}
            />
            <div className="mt-3 flex items-center gap-3">
              <button
                onClick={() => setViewMode('split')}
                className="px-4 py-2 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs font-bold text-emerald-300 hover:bg-emerald-500/25 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                <span>Open Dashboard Inspector</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Initial / On-Demand Choose Your Phone Modal */}
      {state.showPhoneSelector && (
        <PhoneSelectorModal
          currentPhoneId={state.selectedPhone}
          onSelectPhone={handleSelectPhone}
          onClose={() => setState(prev => ({ ...prev, showPhoneSelector: false }))}
          isInitialSetup={state.currentView === 'home' && state.timeMinutes === 485}
        />
      )}

      {/* Mission Briefing & Tasks Summary Modal (Shown right after phone selection or on click) */}
      {state.showMissionBriefing && (
        <MissionBriefingModal
          onStartGame={() => setState(prev => ({ ...prev, showMissionBriefing: false }))}
          onClose={() => setState(prev => ({ ...prev, showMissionBriefing: false }))}
          phoneName={currentPhoneConfig.name}
          startingBattery={state.battery}
        />
      )}

      {/* Layout Anatomy Modal Dialog */}
      {activeModal === 'anatomy' && (
        <div className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-xl w-full bg-neutral-900 border border-white/15 rounded-2xl p-6 text-neutral-200 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <span>📐</span> Dashboard Layout Architecture &amp; Objectives
              </h3>
              <button 
                onClick={() => setActiveModal('none')}
                className="text-xs text-neutral-400 hover:text-white px-2 py-1 rounded cursor-pointer"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-neutral-300">
              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <span className="font-bold text-emerald-400 block mb-1">1. Choose Your Hardware &amp; Read Briefing</span>
                Select from 4 authentic models with distinct battery health levels. A clear mission summary lays out your 3 tasks: reply to Mr. Sterling, navigate to Suite 400, and arrive before 9:15 AM.
              </div>

              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <span className="font-bold text-sky-400 block mb-1">2. Dynamic Moving GPS Pointer</span>
                As you walk or ride transit, the SVG map's radar pointer physically transitions to your new coordinates and displays live location status.
              </div>

              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <span className="font-bold text-purple-400 block mb-1">3. Direct Ending Triggers</span>
                Arriving at Apex Plaza automatically opens the elevator prompt to conclude your interview, with automatic triggers when battery dies or time reaches 9:15 AM.
              </div>
            </div>

            <div className="pt-2 text-right">
              <button 
                onClick={() => setActiveModal('none')}
                className="px-4 py-2 bg-emerald-500 text-black font-bold text-xs rounded-xl hover:bg-emerald-400 transition-colors cursor-pointer"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clean, unboxed footer with subtle separators */}
      <footer className="relative z-10 py-4 px-6 border-t border-emerald-500/10 text-center text-xs text-neutral-500 flex flex-wrap items-center justify-center gap-2">
        <span>The Last 1% Panic Simulator</span>
        <span aria-hidden="true">·</span>
        <span>A Reflection on Human Connection vs Screen Addiction</span>
        <span aria-hidden="true">·</span>
        <span>Audio Synthesizer Enabled</span>
        <span aria-hidden="true">·</span>
        <span className="text-emerald-400/80 font-mono">1440px Desktop Baseline</span>
      </footer>

    </div>
  );
}
