import React from 'react';
import { ScenarioId } from '../types';
import { SCENARIOS } from '../data/initialData';
import * as Sound from '../utils/audio';
import { Compass, Sparkles, Heart, Briefcase, Clock, MapPin, X, ArrowRight } from 'lucide-react';

interface ScenarioSelectorModalProps {
  currentScenario: ScenarioId;
  onSelectScenario: (scenarioId: ScenarioId) => void;
  onClose?: () => void;
}

export const ScenarioSelectorModal: React.FC<ScenarioSelectorModalProps> = ({
  currentScenario,
  onSelectScenario,
  onClose
}) => {
  return (
    <div className="fixed inset-0 z-[310] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto">
      <div className="max-w-4xl w-full bg-neutral-950 border border-emerald-500/25 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 my-auto text-neutral-100">
        
        {/* Header */}
        <div className="flex justify-between items-start border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-1">
              <Compass className="w-4 h-4" />
              <span>Choose Your Smartphone Narrative</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              Select Your Panic Scenario
            </h2>
            <p className="text-xs sm:text-sm text-neutral-400 mt-1">
              Three completely unique storylines testing your ability to balance dying battery, digital temptations, and real human connection.
            </p>
          </div>

          {onClose && (
            <button 
              onClick={onClose}
              className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Scenarios Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {SCENARIOS.map(sc => {
            const isSelected = sc.id === currentScenario;
            return (
              <div 
                key={sc.id}
                onClick={() => {
                  Sound.playTap();
                  onSelectScenario(sc.id);
                }}
                className={`p-4 sm:p-5 rounded-2xl border text-left cursor-pointer transition-all flex flex-col justify-between relative group ${
                  isSelected 
                    ? 'bg-emerald-500/10 border-emerald-400 ring-1 ring-emerald-400/50 shadow-xl' 
                    : 'bg-neutral-900/80 border-white/10 hover:border-white/20 hover:bg-neutral-900'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-3xl">{sc.icon}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/10 text-neutral-300 font-bold">
                      {sc.tag}
                    </span>
                  </div>

                  <h3 className="text-base font-extrabold text-white group-hover:text-emerald-300 transition-colors">
                    {sc.title}
                  </h3>
                  <div className="text-xs text-emerald-400 font-medium mt-0.5">
                    {sc.subtitle}
                  </div>

                  <p className="text-xs text-neutral-300 leading-relaxed mt-2.5 mb-3">
                    {sc.desc}
                  </p>
                </div>

                <div className="space-y-2 pt-3 border-t border-white/10 text-xs">
                  <div className="flex items-center gap-1.5 text-neutral-400">
                    <MapPin className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span className="truncate">Target: <strong className="text-white">{sc.targetName}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 text-neutral-400">
                    <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Deadline: <strong className="text-white">{sc.targetTimeFormatted}</strong></span>
                  </div>

                  <div className="pt-2 flex justify-between items-center">
                    <span className="text-[11px] text-neutral-400 font-mono">
                      {sc.id === 'farewell' ? 'Midnight Pier' : sc.id === 'date' ? 'Evening Romance' : 'Morning Sprint'}
                    </span>
                    <span className={`text-xs font-bold px-3 py-1 rounded-lg flex items-center gap-1 ${
                      isSelected 
                        ? 'bg-emerald-500 text-black' 
                        : 'bg-white/10 text-white group-hover:bg-white/20'
                    }`}>
                      <span>{isSelected ? 'Active ✓' : 'Select'}</span>
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Close / Start Button */}
        <div className="flex justify-end pt-2">
          <button 
            onClick={() => {
              Sound.playTap();
              if (onClose) onClose();
            }}
            className="w-full sm:w-auto px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer"
          >
            Start Scenario →
          </button>
        </div>

      </div>
    </div>
  );
};
