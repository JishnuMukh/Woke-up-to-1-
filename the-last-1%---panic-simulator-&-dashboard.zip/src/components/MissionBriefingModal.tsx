import React from 'react';
import * as Sound from '../utils/audio';
import { 
  Target, 
  Clock, 
  MessageSquare, 
  MapPin, 
  AlertTriangle, 
  BatteryLow, 
  CheckCircle2, 
  Smile, 
  X,
  Play
} from 'lucide-react';

interface MissionBriefingModalProps {
  onStartGame: () => void;
  onClose?: () => void;
  phoneName?: string;
  startingBattery?: number;
}

export const MissionBriefingModal: React.FC<MissionBriefingModalProps> = ({
  onStartGame,
  onClose,
  phoneName = "Your Smartphone",
  startingBattery = 7.5
}) => {
  return (
    <div className="fixed inset-0 z-[320] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto">
      <div className="max-w-2xl w-full bg-neutral-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 my-auto text-neutral-100">
        
        {/* Header */}
        <div className="flex justify-between items-start border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-1">
              <Target className="w-4 h-4" />
              <span>Mission Briefing · Saturday 8:05 AM</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              The Last 1% Survival Challenge
            </h2>
            <p className="text-xs sm:text-sm text-neutral-400 mt-1">
              You woke up with <span className="text-amber-400 font-bold">{startingBattery}% battery</span> on your {phoneName}. You have a high-stakes final partner interview across town in 70 minutes.
            </p>
          </div>

          {onClose && (
            <button 
              onClick={onClose}
              className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* 3 Core Tasks */}
        <div className="space-y-3">
          <div className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
            Your 3 Primary Objectives:
          </div>

          <div className="grid grid-cols-1 gap-2.5">
            <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-white/10 flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm shrink-0 mt-0.5">
                1
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                  Reply to Mr. Sterling in Messages
                </div>
                <p className="text-xs text-neutral-400 mt-0.5 leading-relaxed">
                  The executive partner texted you at 8:02 AM. Reply promptly before they assume you flaked and cancel your slot.
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-white/10 flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-sm shrink-0 mt-0.5">
                2
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-sky-400" />
                  Navigate to Suite 400, Apex Tech Tower
                </div>
                <p className="text-xs text-neutral-400 mt-0.5 leading-relaxed">
                  Use Maps to chart your path, take the subway, or <strong className="text-emerald-300">ask friendly commuters on the street</strong> to save battery! Watch the blue pointer move as you travel.
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900/80 border border-white/10 flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-sm shrink-0 mt-0.5">
                3
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-purple-400" />
                  Arrive Before 9:15 AM Sharp
                </div>
                <p className="text-xs text-neutral-400 mt-0.5 leading-relaxed">
                  When you arrive at Apex Tower, enter Suite 400 to conclude your scenario. If your phone dies, don't panic—your mind, memory, and spoken voice still work!
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Tactical Advice & Traps */}
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed">
            <span className="font-bold text-amber-300 block mb-0.5">Warning: Seductive Digital Traps</span>
            Social apps (Pulse) will tempt you with viral reels and clickbait that eat your final battery. Avoid the temptation to doomscroll, turn on Low Power Mode, and remember that real human beings are standing right beside you.
          </div>
        </div>

        {/* Start Button */}
        <div className="flex justify-end pt-2">
          <button 
            onClick={() => {
              Sound.playTap();
              onStartGame();
            }}
            className="w-full sm:w-auto px-7 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs sm:text-sm rounded-xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>I Understand — Begin Morning Challenge</span>
          </button>
        </div>

      </div>
    </div>
  );
};
