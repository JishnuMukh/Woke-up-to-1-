import React from 'react';
import { PhonePresetId } from '../types';
import { PHONE_MODELS } from '../data/initialData';
import * as Sound from '../utils/audio';
import { Smartphone, BatteryCharging, AlertTriangle, ShieldCheck, Sparkles, X } from 'lucide-react';

interface PhoneSelectorModalProps {
  currentPhoneId: PhonePresetId;
  onSelectPhone: (phoneId: PhonePresetId) => void;
  onClose?: () => void;
  isInitialSetup?: boolean;
}

export const PhoneSelectorModal: React.FC<PhoneSelectorModalProps> = ({
  currentPhoneId,
  onSelectPhone,
  onClose,
  isInitialSetup = false
}) => {
  return (
    <div className="fixed inset-0 z-[300] bg-black/85 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto">
      <div className="max-w-3xl w-full bg-neutral-950 border border-emerald-500/25 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 my-auto">
        
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-1">
              <Smartphone className="w-4 h-4" />
              <span>Choose Your Smartphone &amp; Starting Challenge</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              What device did you wake up with?
            </h2>
            <p className="text-xs sm:text-sm text-neutral-400 mt-1 max-w-xl">
              Each smartphone has authentic hardware characteristics, distinct screen layouts, and battery degradation levels that shape your morning panic.
            </p>
          </div>

          {!isInitialSetup && onClose && (
            <button 
              onClick={onClose}
              className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* 4 Phone Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {PHONE_MODELS.map(phone => {
            const isSelected = phone.id === currentPhoneId;
            return (
              <div 
                key={phone.id}
                onClick={() => {
                  Sound.playTap();
                  onSelectPhone(phone.id);
                }}
                className={`p-4 rounded-2xl border text-left cursor-pointer transition-all flex flex-col justify-between relative group ${
                  isSelected 
                    ? 'bg-emerald-500/10 border-emerald-400 ring-1 ring-emerald-400/50 shadow-lg' 
                    : 'bg-neutral-900/80 border-white/10 hover:border-white/20 hover:bg-neutral-900'
                }`}
              >
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
                        {phone.name}
                      </div>
                      <div className="text-[10px] text-neutral-400 font-medium">
                        {phone.tag}
                      </div>
                    </div>
                    <div className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold ${
                      phone.batteryHealth >= 80 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                      phone.batteryHealth >= 55 ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                      'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    }`}>
                      {phone.batteryHealth}% Health
                    </div>
                  </div>

                  <p className="text-xs text-neutral-300 leading-relaxed mb-3">
                    {phone.desc}
                  </p>
                </div>

                <div className="space-y-2 pt-2 border-t border-white/5">
                  <div className="flex items-center gap-1.5 text-[11px] text-emerald-400">
                    <Sparkles className="w-3.5 h-3.5 shrink-0" />
                    <span><strong className="text-white">Perk:</strong> {phone.perk}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-amber-400/90">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span><strong className="text-white">Risk:</strong> {phone.drawback}</span>
                  </div>

                  <div className="flex items-center justify-between pt-2 mt-1">
                    <span className="text-[11px] font-mono text-neutral-400">
                      Starting Charge: <strong className="text-white">{phone.startingBattery}%</strong>
                    </span>
                    <span className={`text-xs font-bold px-3 py-1 rounded-lg ${
                      isSelected 
                        ? 'bg-emerald-500 text-black' 
                        : 'bg-white/10 text-white group-hover:bg-white/20'
                    }`}>
                      {isSelected ? 'Selected ✓' : 'Select'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Button */}
        <div className="flex justify-end pt-2">
          <button 
            onClick={() => {
              Sound.playTap();
              if (onClose) onClose();
            }}
            className="w-full sm:w-auto px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer"
          >
            Start Smartphone Scenario →
          </button>
        </div>

      </div>
    </div>
  );
};
