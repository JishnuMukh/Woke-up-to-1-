import React, { useState, useEffect } from 'react';
import { 
  SimState, 
  AppId, 
  ScreenView, 
  ChatThread, 
  MapDestination, 
  SocialPost, 
  ChecklistItem,
  PhonePresetId
} from '../types';
import { 
  getInitialChats, 
  MAP_DESTINATIONS, 
  SOCIAL_POSTS, 
  getInitialChecklist,
  PHONE_MODELS,
  STREET_DILEMMAS,
  getCameraScenes,
  getInitialNotes,
  formatSimTime,
  evaluateEnding,
  getInitialSimState
} from '../data/initialData';
import * as Sound from '../utils/audio';
import { 
  Smartphone, 
  Battery, 
  Wifi, 
  WifiOff, 
  Bluetooth, 
  MapPin, 
  Search, 
  Navigation, 
  ArrowLeft, 
  Check, 
  Camera, 
  FileText, 
  Settings, 
  Phone, 
  MessageSquare, 
  DollarSign, 
  Eye, 
  ChevronUp, 
  ExternalLink, 
  DoorOpen, 
  Heart, 
  X, 
  PhoneOff, 
  PhoneIncoming, 
  Clock, 
  Zap, 
  Copy, 
  ListOrdered,
  RotateCcw
} from 'lucide-react';

interface PhoneSimulatorProps {
  state: SimState;
  onUpdateState: React.Dispatch<React.SetStateAction<SimState>>;
  onTriggerNotification: (title: string, message: string, app?: AppId) => void;
  activeNotification: { title: string; message: string; app?: AppId } | null;
  onDismissNotification: () => void;
  onOpenPhoneSelector?: () => void;
  onOpenBriefing?: () => void;
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  state,
  onUpdateState,
  onTriggerNotification,
  activeNotification,
  onDismissNotification,
  onOpenPhoneSelector,
  onOpenBriefing
}) => {
  // Local UI states
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [selectedDestId, setSelectedDestId] = useState<string>('apex');
  const [chats, setChats] = useState<ChatThread[]>(() => getInitialChats(state.doorSecurityCode));
  const [posts, setPosts] = useState<SocialPost[]>(SOCIAL_POSTS);
  const [activeGuiltBanner, setActiveGuiltBanner] = useState<string | null>(null);
  const [copiedCodeToast, setCopiedCodeToast] = useState(false);
  const [isPhotoFlashing, setIsPhotoFlashing] = useState(false);
  const [activeTaskHudOpen, setActiveTaskHudOpen] = useState(false);

  // Sync chats if doorSecurityCode changes (e.g. on new random seed)
  useEffect(() => {
    setChats(getInitialChats(state.doorSecurityCode));
  }, [state.doorSecurityCode]);

  const phoneConfig = PHONE_MODELS.find(p => p.id === state.selectedPhone) || PHONE_MODELS[0];
  const isIOS = state.device.os === 'ios';

  // Mark a task done helper
  const completeTask = (taskId: number) => {
    onUpdateState(prev => ({
      ...prev,
      checklist: prev.checklist.map(c => c.id === taskId ? { ...c, done: true } : c)
    }));
  };

  // Helper to trigger guilt reflection toast
  const triggerGuiltToast = (msg: string) => {
    setActiveGuiltBanner(msg);
    setTimeout(() => {
      setActiveGuiltBanner(prev => prev === msg ? null : prev);
    }, 4500);
  };

  // Consume battery helper with tuned gentle micro-drain
  const consume = (amount: number, appName: AppId | 'idle', heatDelta = 0.5) => {
    onUpdateState(prev => {
      if (prev.isDead || prev.isCharging) return prev;
      
      let multiplier = prev.device.drainMultiplier;
      if (prev.settings.lowPowerMode) multiplier *= 0.5;
      if (prev.settings.greyscaleMode) multiplier *= 0.75;
      if (prev.settings.refreshRate60Hz) multiplier *= 0.8;
      if (!prev.settings.backgroundAppRefresh) multiplier *= 0.75;
      multiplier *= (0.7 + prev.settings.brightness * 0.5);
      if (prev.settings.flashlight) multiplier *= 1.3;

      if (prev.cpuTemp >= 46) multiplier *= 1.2;

      const actualDrain = Math.round((amount * multiplier) * 1000) / 1000;
      const nextBattery = Math.max(0, Math.round((prev.battery - actualDrain) * 100) / 100);
      const isDead = nextBattery <= 0;
      const nextTemp = Math.min(52, Math.max(32, prev.cpuTemp + (prev.settings.lowPowerMode ? heatDelta * 0.3 : heatDelta)));

      if (isDead && !prev.isDead) {
        Sound.playPhoneDeath();
      }

      return {
        ...prev,
        battery: nextBattery,
        cpuTemp: nextTemp,
        isDead,
        currentView: isDead ? 'shutdown' : prev.currentView,
        appUsage: {
          ...prev.appUsage,
          [appName]: {
            ...prev.appUsage[appName],
            batterySpent: Math.round((prev.appUsage[appName].batterySpent + actualDrain) * 100) / 100,
            interactions: prev.appUsage[appName].interactions + 1
          }
        }
      };
    });
  };

  // Advance time helper
  const advanceTimeMins = (minutes: number, appName: AppId | 'idle' = 'idle') => {
    onUpdateState(prev => {
      const nextTime = Math.round((prev.timeMinutes + minutes) * 10) / 10;
      return {
        ...prev,
        timeMinutes: nextTime,
        appUsage: {
          ...prev.appUsage,
          [appName]: {
            ...prev.appUsage[appName],
            minutes: prev.appUsage[appName].minutes + minutes
          }
        }
      };
    });
  };

  // Launch App
  const launchApp = (appId: AppId, deepLinkPayload?: string) => {
    Sound.playTap();
    consume(0.015, appId, 0.4);

    onUpdateState(prev => ({
      ...prev,
      activeApp: appId,
      currentView: 'app',
      isControlCenterOpen: false,
      badges: {
        ...prev.badges,
        [appId]: 0
      }
    }));

    if (appId === 'messages' && deepLinkPayload) {
      setActiveChatId(deepLinkPayload);
    }
    if (appId === 'maps') {
      completeTask(2);
      if (deepLinkPayload) {
        setSelectedDestId(deepLinkPayload);
      }
    }
  };

  // Return Home
  const goHome = () => {
    Sound.playTap();
    onUpdateState(prev => ({
      ...prev,
      activeApp: null,
      currentView: 'home',
      isControlCenterOpen: false,
      doorKeypadOpen: false
    }));
  };

  // Toggle Control Center
  const toggleControlCenter = () => {
    Sound.playTap();
    onUpdateState(prev => ({
      ...prev,
      isControlCenterOpen: !prev.isControlCenterOpen
    }));
  };

  // Conclude Scenario & trigger ending directly
  const concludeScenario = () => {
    Sound.playVictoryChime();
    onUpdateState(prev => ({
      ...prev,
      interviewCompleted: true,
      destinationReached: true,
      currentView: 'recap',
      activeApp: null,
      doorKeypadOpen: false,
      interviewArrivedPrompt: false
    }));
  };

  // Full Replay scenario restart - strictly starts from Task 0/5 with fresh random PIN code
  const handleReplayScenario = () => {
    Sound.playTap();
    const freshState = getInitialSimState(state.selectedPhone);
    setChats(getInitialChats(freshState.doorSecurityCode));
    setPosts(SOCIAL_POSTS);
    setActiveChatId(null);
    onUpdateState(() => freshState);
  };

  // Battery chassis vibration & color states
  const isCriticalBattery = state.battery > 0 && state.battery <= 2.5;
  const isLowBattery = state.battery > 0 && state.battery <= 9.9;
  const isThermalThrottled = state.cpuTemp >= 46;

  // Selected Map Destination
  const currentDest = MAP_DESTINATIONS.find(d => d.id === selectedDestId) || MAP_DESTINATIONS[0];
  const minutesToInterview = Math.max(0, Math.round(state.targetInterviewTime - state.timeMinutes));
  const isPlayerAtApex = state.playerPos.x === 252 && state.playerPos.y === 55;
  const cameraScenes = getCameraScenes(state.doorSecurityCode);

  // Multi-step animated walking path handler
  const handleWalkStep = () => {
    if (state.isWalkingProgress) return;
    Sound.playTap();

    const waypoints = [
      { x: 60, y: 160, name: "Transit Plaza" },
      { x: 120, y: 120, name: "4th Avenue Crossing" },
      { x: 175, y: 90, name: "Apex River Bridge" },
      { x: 252, y: 55, name: "Apex Tech Tower (Suite 400)" }
    ];

    onUpdateState(prev => ({ ...prev, isWalkingProgress: true }));
    consume(currentDest.batteryCost, 'maps', 0.8);
    advanceTimeMins(currentDest.etaMins, 'maps');

    let stepIndex = 0;
    const interval = setInterval(() => {
      stepIndex++;
      if (stepIndex < waypoints.length) {
        const wp = waypoints[stepIndex];
        onUpdateState(prev => ({
          ...prev,
          playerPos: { x: wp.x, y: wp.y },
          currentLocation: wp.name,
          walkingStep: stepIndex
        }));
      } else {
        clearInterval(interval);
        const isApex = currentDest.id === 'apex';
        onUpdateState(prev => ({
          ...prev,
          isWalkingProgress: false,
          playerPos: currentDest.svgPos,
          currentLocation: currentDest.name,
          activeNavigation: false,
          destinationReached: isApex ? true : prev.destinationReached,
          interviewArrivedPrompt: isApex ? true : prev.interviewArrivedPrompt
        }));

        if (isApex) {
          completeTask(4);
          onTriggerNotification("Arrived at Apex Tower!", "Suite 400 security entrance reached! Enter now.", "notes");
        }
      }
    }, 600);
  };

  // Dedicated Authentic App Icon Renderer (iOS Squircles vs Android Circles)
  const renderAppIcon = (appId: AppId, isDock = false) => {
    const sizeClasses = isDock ? "w-12 h-12" : "w-13 h-13 sm:w-14 sm:h-14";

    if (isIOS) {
      // AUTHENTIC APPLE iOS SQUIRCLE ICONS
      const squircleBase = `${sizeClasses} rounded-[22.5%] relative flex items-center justify-center shadow-lg transition-transform active:scale-95 group-hover:scale-105 overflow-hidden border border-white/20 shadow-[0_4px_12px_rgba(0,0,0,0.35),inset_0_1px_1px_rgba(255,255,255,0.4)]`;

      switch (appId) {
        case 'messages':
          return (
            <div className={squircleBase} style={{ background: 'linear-gradient(180deg, #34c759 0%, #248a3d 100%)' }}>
              {/* White iOS speech bubble with tail */}
              <div className="w-7 h-5 bg-white rounded-full relative flex items-center justify-center shadow-xs">
                <div className="absolute -bottom-1 -left-0.5 w-2 h-2 bg-white rounded-bl-full" />
              </div>
            </div>
          );
        case 'maps':
          return (
            <div className={squircleBase} style={{ background: 'linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%)' }}>
              {/* Apple Maps road grid with river & navigation arrow */}
              <div className="absolute inset-0 bg-[#e2e8f0]">
                <div className="absolute top-0 right-0 w-8 h-8 bg-[#86efac] rounded-bl-full opacity-80" />
                <div className="absolute bottom-0 left-0 w-full h-3 bg-[#60a5fa] opacity-75" />
                <div className="absolute top-0 left-4 w-2 h-full bg-white shadow-xs" />
                <div className="absolute top-5 left-0 w-full h-2 bg-white shadow-xs" />
              </div>
              <Navigation className="w-6 h-6 fill-[#007aff] text-white drop-shadow relative z-10 -rotate-45" />
            </div>
          );
        case 'social':
          return (
            <div className={squircleBase} style={{ background: '#ffffff' }}>
              {/* Apple Photos / Pulse color petal spectrum */}
              <div className="relative w-8 h-8 flex items-center justify-center">
                <div className="absolute w-2 h-4 bg-[#ef4444] rounded-full top-0 opacity-90" />
                <div className="absolute w-2 h-4 bg-[#f97316] rounded-full top-0.5 right-1 rotate-45 opacity-90" />
                <div className="absolute w-4 h-2 bg-[#eab308] rounded-full right-0 opacity-90" />
                <div className="absolute w-2 h-4 bg-[#22c55e] rounded-full bottom-0.5 right-1 -rotate-45 opacity-90" />
                <div className="absolute w-2 h-4 bg-[#06b6d4] rounded-full bottom-0 opacity-90" />
                <div className="absolute w-2 h-4 bg-[#3b82f6] rounded-full bottom-0.5 left-1 rotate-45 opacity-90" />
                <div className="absolute w-4 h-2 bg-[#a855f7] rounded-full left-0 opacity-90" />
                <div className="absolute w-2 h-4 bg-[#ec4899] rounded-full top-0.5 left-1 -rotate-45 opacity-90" />
                <div className="w-2 h-2 rounded-full bg-white z-10 shadow-xs" />
              </div>
            </div>
          );
        case 'camera':
          return (
            <div className={squircleBase} style={{ background: 'linear-gradient(180deg, #52525b 0%, #27272a 100%)' }}>
              <div className="w-8 h-8 rounded-full border-2 border-neutral-400 bg-neutral-900 flex items-center justify-center relative shadow-inner">
                <div className="w-4 h-4 rounded-full bg-neutral-700 border border-neutral-500 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-sky-400 opacity-90" />
                </div>
                <div className="absolute top-0.5 right-0.5 w-1 h-1 rounded-full bg-amber-400" />
              </div>
            </div>
          );
        case 'phone':
          return (
            <div className={squircleBase} style={{ background: 'linear-gradient(180deg, #30d158 0%, #248a3d 100%)' }}>
              <Phone className="w-6 h-6 fill-white text-white -rotate-12 drop-shadow" />
            </div>
          );
        case 'notes':
          return (
            <div className={squircleBase} style={{ background: '#f8fafc' }}>
              {/* Apple Notes yellow band header & ruled lines */}
              <div className="absolute top-0 inset-x-0 h-4 bg-[#eab308] border-b border-amber-600/30 flex items-center px-1">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-700/40 mr-1" />
              </div>
              <div className="w-full px-2 pt-3 space-y-1">
                <div className="w-full h-[1px] bg-amber-200" />
                <div className="w-3/4 h-[1px] bg-amber-200" />
                <div className="w-5/6 h-[1px] bg-amber-200" />
              </div>
            </div>
          );
        case 'wallet':
          return (
            <div className={squircleBase} style={{ background: '#09090b' }}>
              {/* Apple Wallet stacked card tabs */}
              <div className="relative w-8 h-8 flex flex-col justify-end">
                <div className="w-7 h-3 bg-sky-500 rounded-t-md mx-auto mb-[-6px] shadow-xs" />
                <div className="w-7 h-3.5 bg-emerald-500 rounded-t-md mx-auto mb-[-4px] shadow-xs" />
                <div className="w-8 h-4 bg-orange-500 rounded-t-md shadow-xs border-t border-white/20" />
              </div>
            </div>
          );
        case 'settings':
          return (
            <div className={squircleBase} style={{ background: 'linear-gradient(180deg, #d4d4d8 0%, #71717a 100%)' }}>
              <Settings className="w-7 h-7 text-neutral-800 drop-shadow animate-[spin_12s_linear_infinite]" />
            </div>
          );
      }
    } else {
      // AUTHENTIC ANDROID MATERIAL CIRCLE ICONS
      const circleBase = `${sizeClasses} rounded-full relative flex items-center justify-center shadow-md transition-transform active:scale-95 group-hover:scale-105 overflow-hidden`;

      switch (appId) {
        case 'messages':
          return (
            <div className={`${circleBase} bg-[#1a73e8]`}>
              <MessageSquare className="w-6 h-6 text-white fill-white" />
            </div>
          );
        case 'maps':
          return (
            <div className={`${circleBase} bg-white border border-neutral-200`}>
              <MapPin className="w-6 h-6 text-red-500 fill-red-500" />
            </div>
          );
        case 'social':
          return (
            <div className={`${circleBase} bg-gradient-to-tr from-pink-600 to-amber-500`}>
              <Heart className="w-6 h-6 text-white fill-white" />
            </div>
          );
        case 'camera':
          return (
            <div className={`${circleBase} bg-[#202124]`}>
              <Camera className="w-6 h-6 text-teal-400" />
            </div>
          );
        case 'phone':
          return (
            <div className={`${circleBase} bg-[#0f9d58]`}>
              <Phone className="w-6 h-6 text-white fill-white" />
            </div>
          );
        case 'notes':
          return (
            <div className={`${sizeClasses} rounded-2xl bg-[#fbbc04] relative flex items-center justify-center shadow-md`}>
              <FileText className="w-6 h-6 text-neutral-900" />
            </div>
          );
        case 'wallet':
          return (
            <div className={`${circleBase} bg-white border border-neutral-200`}>
              <DollarSign className="w-6 h-6 text-blue-600" />
            </div>
          );
        case 'settings':
          return (
            <div className={`${circleBase} bg-[#3c4043]`}>
              <Settings className="w-6 h-6 text-neutral-200" />
            </div>
          );
      }
    }
  };

  return (
    <div className="relative flex flex-col items-center py-1 select-none">
      
      {/* Top Device Banner with Quick Switcher Buttons */}
      <div className="w-[375px] flex items-center justify-between px-3 py-1.5 mb-1.5 text-xs text-neutral-400">
        <div className="flex items-center gap-1.5 truncate">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: phoneConfig.accentColor }} />
          <span className="font-semibold text-neutral-200 truncate">{phoneConfig.name}</span>
          <span className="text-[10px] text-neutral-500 font-mono">({phoneConfig.batteryHealth}% Health)</span>
        </div>
        <div className="flex items-center gap-2">
          {onOpenBriefing && (
            <button 
              onClick={onOpenBriefing}
              className="text-[11px] text-amber-400 hover:text-amber-300 font-bold hover:underline cursor-pointer flex items-center gap-1"
            >
              <span>Briefing 📋</span>
            </button>
          )}
          {onOpenPhoneSelector && (
            <button 
              onClick={onOpenPhoneSelector}
              className="text-[11px] text-emerald-400 hover:text-emerald-300 font-bold hover:underline cursor-pointer"
            >
              Change ⇄
            </button>
          )}
        </div>
      </div>

      {/* Smartphone Outer Hardware Chassis */}
      <div 
        className={`relative w-[375px] h-[780px] rounded-[52px] p-[10px] shadow-[0_30px_90px_rgba(0,0,0,0.85),0_0_0_1px_rgba(255,255,255,0.12),inset_0_0_0_2px_rgba(255,255,255,0.06)] transition-all duration-300 ${
          isCriticalBattery ? 'animate-[shake_0.25s_infinite] shadow-[0_0_50px_rgba(239,68,68,0.4)]' : ''
        }`}
        style={{
          background: state.selectedPhone === 'iphone18pro' 
            ? 'linear-gradient(180deg, #292524 0%, #1c1917 50%, #0c0a09 100%)'
            : state.selectedPhone === 'android2017'
              ? 'linear-gradient(180deg, #1f2937 0%, #111827 50%, #030712 100%)'
              : state.selectedPhone === 'iphone7'
                ? 'linear-gradient(180deg, #3f3f46 0%, #27272a 50%, #18181b 100%)'
                : 'linear-gradient(180deg, #3730a3 0%, #1e1b4b 50%, #0f172a 100%)'
        }}
      >
        {/* Hardware side buttons */}
        <div className="absolute -left-[3px] top-[115px] w-[3px] h-[28px] bg-neutral-800 rounded-l-sm" />
        <div className="absolute -left-[3px] top-[155px] w-[3px] h-[52px] bg-neutral-800 rounded-l-sm" />
        <div className="absolute -left-[3px] top-[215px] w-[3px] h-[52px] bg-neutral-800 rounded-l-sm" />
        <div className="absolute -right-[3px] top-[165px] w-[3px] h-[75px] bg-neutral-800 rounded-r-sm" />

        {/* Inner Smartphone Screen Container */}
        <div 
          className="relative w-full h-full bg-[#050907] rounded-[42px] overflow-hidden flex flex-col shadow-inner"
          style={{
            filter: `brightness(${isThermalThrottled ? 0.4 : 0.5 + state.settings.brightness * 0.5}) ${state.settings.greyscaleMode ? 'grayscale(100%)' : ''}`
          }}
        >
          {/* Subtle Crease overlay for foldable */}
          {phoneConfig.bezelStyle === 'fold_crease' && (
            <div className="absolute inset-x-0 top-1/2 h-1 bg-white/10 blur-[1px] pointer-events-none z-50" />
          )}

          {/* Cracked screen SVG overlay for 2017 Android */}
          {phoneConfig.hasCrackOverlay && (
            <svg className="absolute inset-0 w-full h-full pointer-events-none z-50 opacity-40">
              <path d="M 12 15 L 45 65 L 75 50 L 110 95 M 45 65 L 30 140 M 110 95 L 140 85 L 165 145" stroke="#ffffff" strokeWidth="1.2" fill="none" opacity="0.6" />
              <path d="M 0 35 L 55 75 L 85 180" stroke="#ffffff" strokeWidth="0.8" fill="none" opacity="0.5" />
            </svg>
          )}

          {/* Low Battery Vignette Glow & Pulse */}
          {isCriticalBattery && (
            <div className="absolute inset-0 pointer-events-none z-40 bg-gradient-to-t from-red-950/40 via-transparent to-red-950/20 animate-pulse" />
          )}

          {/* 1. TOP HARDWARE BEZEL & DYNAMIC ISLAND */}
          <div className="relative z-50 pt-2 px-6 flex justify-between items-center text-xs font-semibold text-white select-none">
            {/* Clock display */}
            <span className="font-mono text-xs tabular-nums tracking-tight">
              {formatSimTime(state.timeMinutes)}
            </span>

            {/* Dynamic Island pill or sensor notch */}
            {phoneConfig.bezelStyle === 'dynamic_island' ? (
              <div 
                onClick={toggleControlCenter}
                className="cursor-pointer mx-auto bg-black text-white px-3 py-1 rounded-full flex items-center gap-2 border border-white/10 shadow-md hover:scale-105 transition-transform"
                title="Tap Dynamic Island for Quick Settings"
              >
                {activeNotification ? (
                  <span className="text-[10px] text-amber-300 font-bold truncate max-w-[130px] animate-pulse">
                    {activeNotification.title}
                  </span>
                ) : (
                  <>
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                    <span className="text-[10px] text-neutral-300 font-medium">Apex Tech 400</span>
                  </>
                )}
              </div>
            ) : phoneConfig.bezelStyle === 'classic_home_button' ? (
              <div className="mx-auto flex items-center gap-2">
                <div className="w-12 h-1 bg-neutral-800 rounded-full" />
                <div className="w-2 h-2 rounded-full bg-neutral-900 border border-neutral-700" />
              </div>
            ) : (
              <div className="w-16 h-4 bg-black rounded-b-xl mx-auto flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-neutral-800" />
              </div>
            )}

            {/* Top Right Status Icons */}
            <div 
              onClick={toggleControlCenter}
              className="flex items-center gap-1.5 cursor-pointer font-mono"
              title="Click to open Quick Settings"
            >
              {state.settings.wifi ? <Wifi className="w-3 h-3 text-neutral-300" /> : <WifiOff className="w-3 h-3 text-rose-400" />}
              {state.settings.bluetooth && <Bluetooth className="w-3 h-3 text-neutral-300" />}
              
              {/* Battery Badge - clearly displaying 1 decimal under 10% */}
              <div className={`flex items-center gap-0.5 px-1 py-0.5 rounded text-[10px] font-bold ${
                state.battery <= 2.5 
                  ? 'bg-rose-500/30 text-rose-400 border border-rose-500/50 animate-pulse' 
                  : state.battery <= 10 
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' 
                    : 'text-neutral-200'
              }`}>
                <span>{state.battery.toFixed(state.battery < 10 ? 1 : 0)}%</span>
                {state.isCharging ? <Zap className="w-2.5 h-2.5 text-yellow-400 fill-current" /> : <Battery className="w-3 h-3" />}
              </div>
            </div>
          </div>

          {/* Quick Notification Pill dropdown */}
          {activeNotification && (
            <div 
              onClick={() => {
                if (activeNotification.app) launchApp(activeNotification.app);
                onDismissNotification();
              }}
              className="absolute top-11 inset-x-3 z-[110] bg-neutral-900/95 border border-white/20 backdrop-blur-xl rounded-2xl p-3 shadow-2xl cursor-pointer hover:border-emerald-400/50 transition-all flex items-start justify-between"
            >
              <div className="flex-1 pr-2">
                <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 mb-0.5">
                  {activeNotification.title}
                </div>
                <div className="text-xs font-semibold text-white leading-snug">
                  {activeNotification.message}
                </div>
              </div>
              <button 
                onClick={(e) => { e.stopPropagation(); onDismissNotification(); }}
                className="text-neutral-400 hover:text-white p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Task HUD Dropdown Drawer (Always available so user is never lost) */}
          {activeTaskHudOpen && (
            <div className="absolute top-11 inset-x-3 z-[120] bg-neutral-950/95 border border-amber-500/40 backdrop-blur-2xl rounded-2xl p-3.5 shadow-2xl text-left">
              <div className="flex justify-between items-center border-b border-white/10 pb-2 mb-2.5">
                <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <ListOrdered className="w-3.5 h-3.5" />
                  <span>Mission Checklist ({state.checklist.filter(c => c.done).length}/{state.checklist.length})</span>
                </div>
                <button onClick={() => setActiveTaskHudOpen(false)} className="text-neutral-400 hover:text-white">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="space-y-1.5">
                {state.checklist.map(item => (
                  <div key={item.id} className="flex items-center gap-2 text-xs">
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      item.done ? 'bg-emerald-500 text-black' : 'border border-neutral-600 text-neutral-500'
                    }`}>
                      {item.done ? '✓' : ''}
                    </div>
                    <span className={item.done ? 'line-through text-neutral-500' : 'text-neutral-200 font-medium'}>
                      {item.text}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-3 pt-2 border-t border-white/10 flex justify-between items-center text-[10px] text-neutral-400">
                <span>Code Clue: <strong className="text-amber-400">Check Texts/Calls/Camera</strong></span>
                <span>Deadline: <strong className="text-white font-mono">9:15 AM</strong></span>
              </div>
            </div>
          )}

          {/* INCOMING PHONE CALL FULL-SCREEN OVERLAY */}
          {state.incomingCallActive && state.currentIncomingCall && (
            <div className="absolute inset-0 z-[150] bg-neutral-950/98 backdrop-blur-2xl flex flex-col justify-between p-6 text-center animate-in fade-in">
              <div className="pt-8">
                <div className="w-20 h-20 rounded-full bg-neutral-800 border-2 border-emerald-400 mx-auto flex items-center justify-center text-4xl mb-3 shadow-xl animate-pulse">
                  {state.currentIncomingCall.avatar}
                </div>
                <h3 className="text-lg font-extrabold text-white">
                  {state.currentIncomingCall.callerName}
                </h3>
                <div className="text-xs text-neutral-400 font-mono mt-0.5">
                  {state.currentIncomingCall.callerNumber}
                </div>
                <div className="text-xs text-emerald-400 font-semibold mt-1">
                  {state.currentIncomingCall.subtitle}
                </div>
              </div>

              {/* Dialogue Box if Answered */}
              {state.activeCallConnected ? (
                <div className="bg-neutral-900 border border-white/10 rounded-2xl p-4 text-left space-y-3 shadow-xl">
                  <div className="text-xs text-neutral-200 leading-relaxed font-medium">
                    "{state.currentIncomingCall.dialogueText}"
                  </div>

                  <div className="space-y-1.5 pt-1">
                    <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                      Select Spoken Response:
                    </div>
                    {state.currentIncomingCall.responses.map((resp, rIdx) => (
                      <button
                        key={rIdx}
                        onClick={() => {
                          Sound.playTap();
                          consume(resp.batteryCost, 'phone', 0.5);
                          advanceTimeMins(1, 'phone');
                          if (resp.revealsCode) {
                            completeTask(3);
                          }
                          onUpdateState(prev => ({
                            ...prev,
                            incomingCallActive: false,
                            activeCallConnected: false,
                            socialConnection: Math.min(100, prev.socialConnection + resp.socialDelta)
                          }));
                          onTriggerNotification("Call Ended", resp.reply, "phone");
                        }}
                        className="w-full text-left p-2.5 rounded-xl bg-white/5 hover:bg-emerald-500/20 border border-white/10 text-xs text-white transition-all cursor-pointer"
                      >
                        🗣️ "{resp.text}"
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-xs text-neutral-400 animate-pulse">
                  Incoming Voice Call...
                </div>
              )}

              {/* Accept & Decline Buttons */}
              {!state.activeCallConnected && (
                <div className="flex justify-around items-center pb-8">
                  <button 
                    onClick={() => {
                      Sound.playTap();
                      onUpdateState(prev => ({ ...prev, incomingCallActive: false }));
                    }}
                    className="flex flex-col items-center gap-1.5 cursor-pointer"
                  >
                    <div className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg transition-transform active:scale-90">
                      <PhoneOff className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold text-neutral-400">Decline</span>
                  </button>

                  <button 
                    onClick={() => {
                      Sound.playTap();
                      onUpdateState(prev => ({ ...prev, activeCallConnected: true }));
                    }}
                    className="flex flex-col items-center gap-1.5 cursor-pointer"
                  >
                    <div className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-black flex items-center justify-center shadow-lg transition-transform active:scale-90 animate-bounce">
                      <PhoneIncoming className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold text-emerald-400">Answer</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ARRIVAL MODAL WHEN AT APEX TOWER (ORGANIC ENDING TRIGGER) */}
          {state.interviewArrivedPrompt && (
            <div className="absolute inset-0 z-[140] bg-black/90 backdrop-blur-xl flex flex-col justify-center p-6 text-center animate-in fade-in">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 mx-auto flex items-center justify-center text-3xl mb-3 shadow-xl">
                🏢
              </div>
              <h3 className="text-lg font-extrabold text-white">
                You Arrived at Apex Tech Tower!
              </h3>
              <p className="text-xs text-neutral-300 mt-1 leading-relaxed max-w-[260px] mx-auto">
                Suite 400 is on the 4th floor. Enter the secret security code you found on your phone or ask the guard!
              </p>

              <div className="space-y-2 mt-5">
                <button 
                  onClick={() => {
                    Sound.playTap();
                    onUpdateState(prev => ({ ...prev, doorKeypadOpen: true, interviewArrivedPrompt: false }));
                  }}
                  className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer flex items-center justify-center gap-2"
                >
                  <DoorOpen className="w-4 h-4" />
                  <span>Enter Code on Security Keypad →</span>
                </button>

                <button 
                  onClick={() => {
                    Sound.playSocialBoost();
                    onUpdateState(prev => ({
                      ...prev,
                      interviewArrivedPrompt: false,
                      doorUnlocked: true,
                      socialConnection: Math.min(100, prev.socialConnection + 25),
                      humanMomentsLogged: [...prev.humanMomentsLogged, `Greeted the front desk security guard who warmly unlocked the 4th floor elevator!`]
                    }));
                    completeTask(5);
                    concludeScenario();
                  }}
                  className="w-full py-2.5 bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/30 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  🤝 Speak to Front Desk Guard Instead (Human Connection)
                </button>
              </div>
            </div>
          )}

          {/* SUITE 400 ELEVATOR KEYPAD MODAL (ACCEPTS DYNAMIC CODE) */}
          {state.doorKeypadOpen && (
            <div className="absolute inset-0 z-[130] bg-neutral-950/98 backdrop-blur-2xl flex flex-col justify-between p-5 text-center animate-in fade-in">
              <div className="pt-2">
                <div className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center justify-center gap-1.5">
                  <DoorOpen className="w-4 h-4" />
                  <span>Apex Tower Security Gate</span>
                </div>
                <h3 className="text-base font-extrabold text-white mt-0.5">
                  Suite 400 Keypad Access
                </h3>
                <p className="text-[11px] text-neutral-400 mt-0.5">
                  Hint: Code is in Mr. Sterling's text, Notes prep, Sarah's call, or Lobby Directory
                </p>
              </div>

              {/* Code Display */}
              <div className="h-11 bg-neutral-900 border border-white/15 rounded-2xl flex items-center justify-center text-xl font-mono tracking-widest text-emerald-400">
                {state.doorCodeEntered || '_ _ _ _'}
              </div>

              {/* Security Keypad Matrix */}
              <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto w-full">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9', '#', '0', 'C'].map(k => (
                  <button 
                    key={k}
                    onClick={() => {
                      Sound.playDTMF(k);
                      if (k === 'C') {
                        onUpdateState(prev => ({ ...prev, doorCodeEntered: '' }));
                      } else {
                        const nextCode = (state.doorCodeEntered + k).slice(0, 5);
                        onUpdateState(prev => ({ ...prev, doorCodeEntered: nextCode }));

                        // Check if entered code matches random security code
                        const targetCodeWithHash = state.doorSecurityCode;
                        const targetCodeNoHash = state.doorSecurityCode.replace('#', '');
                        if (nextCode === targetCodeWithHash || nextCode === targetCodeNoHash) {
                          Sound.playVictoryChime();
                          completeTask(3);
                          onUpdateState(prev => ({
                            ...prev,
                            doorUnlocked: true,
                            doorKeypadOpen: false
                          }));
                          concludeScenario();
                        }
                      }
                    }}
                    className="w-13 h-13 rounded-full bg-neutral-900 border border-white/10 active:bg-neutral-800 text-lg font-bold flex items-center justify-center cursor-pointer mx-auto text-white hover:border-emerald-500/40"
                  >
                    {k}
                  </button>
                ))}
              </div>

              {/* Alternatives & Cancel */}
              <div className="space-y-1.5 pt-1">
                <button 
                  onClick={() => {
                    Sound.playSocialBoost();
                    completeTask(5);
                    onUpdateState(prev => ({
                      ...prev,
                      doorUnlocked: true,
                      doorKeypadOpen: false,
                      socialConnection: Math.min(100, prev.socialConnection + 20),
                      humanMomentsLogged: [...prev.humanMomentsLogged, `Asked front desk security for elevator access`]
                    }));
                    concludeScenario();
                  }}
                  className="w-full py-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  🤝 Ask Security Guard at Desk (Human Connection)
                </button>

                <button 
                  onClick={() => onUpdateState(prev => ({ ...prev, doorKeypadOpen: false }))}
                  className="w-full text-center text-xs text-neutral-400 hover:text-white py-1 cursor-pointer"
                >
                  Close &amp; Check Phone
                </button>
              </div>
            </div>
          )}

          {/* Psychological Guilt Conscience Banner */}
          {activeGuiltBanner && (
            <div className="absolute top-12 inset-x-3 z-[115] bg-neutral-900/95 border border-amber-500/40 rounded-2xl p-2.5 shadow-2xl animate-in fade-in slide-in-from-top-2">
              <div className="flex items-start gap-2">
                <span className="text-amber-400 text-sm">👁️</span>
                <div className="text-left">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                    Conscience Mirror
                  </span>
                  <p className="text-[11px] text-neutral-200 leading-snug">
                    {activeGuiltBanner}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* MAIN SCREEN ROUTING */}
          <div className="flex-1 flex flex-col overflow-hidden relative">

            {/* SCREEN 1: Lock Screen */}
            {state.currentView === 'lock' && (
              <div className="flex-1 flex flex-col justify-between items-center px-6 pt-12 pb-6 bg-gradient-to-b from-[#0f2415] via-[#09150c] to-[#040805] text-white">
                <div className="flex flex-col items-center">
                  <span className="text-sm font-medium text-emerald-200/80 mb-1">
                    Saturday, October 3
                  </span>
                  <span className="text-6xl font-extrabold tracking-tighter tabular-nums font-mono">
                    {formatSimTime(state.timeMinutes).replace(/ [AP]M/, '')}
                  </span>
                  <div className="mt-2.5 flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-semibold border border-white/15">
                    <span>🔋</span>
                    <span className="tabular-nums font-mono text-rose-400 font-bold">{state.battery.toFixed(1)}% Battery Remaining</span>
                  </div>
                </div>

                {/* Lock Screen Notification Card */}
                <div 
                  onClick={() => launchApp('messages', 'boss')}
                  className="w-full bg-neutral-900/80 backdrop-blur-xl border border-white/15 rounded-2xl p-3.5 text-left cursor-pointer hover:border-emerald-400/50 transition-all shadow-lg"
                >
                  <div className="flex justify-between items-center text-[10px] font-bold text-neutral-400 uppercase tracking-wider mb-1">
                    <span>👔 Messages · 8:02 AM</span>
                    <span className="text-emerald-400">Tap to reply</span>
                  </div>
                  <div className="text-xs font-bold text-white mb-0.5">
                    Mr. Sterling (Apex Partner)
                  </div>
                  <div className="text-[11px] text-neutral-300 leading-snug line-clamp-2">
                    Reminder: Partner interview begins at 9:15 AM sharp in Suite 400. Elevator PIN code sent.
                  </div>
                </div>

                {/* Unlock Swipe/Tap Prompt */}
                <button 
                  onClick={() => {
                    Sound.playTap();
                    onUpdateState(prev => ({ ...prev, currentView: 'home' }));
                  }}
                  className="flex flex-col items-center gap-1 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                >
                  <ChevronUp className="w-5 h-5 animate-bounce" />
                  <span className="text-xs font-semibold">Tap to Unlock</span>
                </button>
              </div>
            )}

            {/* SCREEN 2: Home Screen (THE DASHBOARD WITH AUTHENTIC ICONS) */}
            {state.currentView === 'home' && (
              <div className="flex-1 flex flex-col justify-between px-4 pt-3.5 pb-3 bg-gradient-to-b from-[#0c1f10] via-[#070f08] to-[#030604] text-white overflow-hidden space-y-2">
                
                {/* 1. Top Glance Widget (Target Objective & Battery Status) */}
                <div className="bg-neutral-900/70 border border-emerald-500/20 backdrop-blur-xl rounded-2xl p-3 flex items-center justify-between shadow-lg shrink-0">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                      Target Objective
                    </span>
                    <span className="text-sm font-bold text-white mt-0.5">
                      Apex Tech Suite 400
                    </span>
                    <span className={`text-[11px] font-semibold mt-0.5 flex items-center gap-1 ${
                      state.destinationReached 
                        ? 'text-emerald-400' 
                        : minutesToInterview <= 15 
                          ? 'text-rose-400' 
                          : 'text-amber-400'
                    }`}>
                      <Clock className="w-3 h-3" />
                      {state.destinationReached 
                        ? '✓ Arrived at Apex Plaza' 
                        : `${minutesToInterview}m until 9:15 AM interview`}
                    </span>
                  </div>

                  <div className={`w-12 h-12 rounded-full border-2 flex flex-col items-center justify-center font-mono font-bold text-xs shadow-md shrink-0 ${
                    state.battery <= 2.5 
                      ? 'border-rose-500 text-rose-400 bg-rose-950/40 animate-pulse' 
                      : state.battery <= 10 
                        ? 'border-amber-500 text-amber-400 bg-amber-950/30' 
                        : 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                  }`}>
                    <span className="text-[10px] leading-none">{state.battery.toFixed(1)}%</span>
                  </div>
                </div>

                {/* 2. Interactive Mission HUD Button */}
                <div 
                  onClick={() => setActiveTaskHudOpen(!activeTaskHudOpen)}
                  className="bg-neutral-900/80 border border-white/10 hover:border-amber-400/40 rounded-xl px-3 py-2 flex items-center justify-between cursor-pointer transition-colors shadow-md"
                >
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-amber-400">📋</span>
                    <span className="font-semibold text-neutral-200">Current Task:</span>
                    <span className="text-amber-300 text-[11px] truncate max-w-[160px]">
                      {state.checklist.find(c => !c.done)?.text || "Enter Suite 400!"}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-neutral-400 bg-white/5 px-2 py-0.5 rounded-full">
                    {state.checklist.filter(c => c.done).length}/5 Tasks
                  </span>
                </div>

                {/* 3. 8-App Grid (AUTHENTIC ICONS BASED ON CHOSEN PHONE OS) */}
                <div className="grid grid-cols-4 gap-y-3.5 gap-x-2 py-1 shrink-0">
                  
                  {/* App 1: Messages */}
                  <div 
                    onClick={() => launchApp('messages')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="relative">
                      {renderAppIcon('messages')}
                      {state.badges.messages > 0 && (
                        <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full border border-black animate-pulse z-20">
                          {state.badges.messages}
                        </span>
                      )}
                    </div>
                    <span className="text-[10.5px] font-medium text-neutral-200 tracking-tight">Messages</span>
                  </div>

                  {/* App 2: Maps */}
                  <div 
                    onClick={() => launchApp('maps')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="relative">
                      {renderAppIcon('maps')}
                      {state.activeNavigation && (
                        <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 absolute top-1 right-1 animate-ping z-20" />
                      )}
                    </div>
                    <span className="text-[10.5px] font-medium text-neutral-200 tracking-tight">Maps</span>
                  </div>

                  {/* App 3: Social (Pulse) */}
                  <div 
                    onClick={() => launchApp('social')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="relative">
                      {renderAppIcon('social')}
                      {state.badges.social > 0 && (
                        <span className="absolute -top-1 -right-1 bg-rose-600 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full border border-black z-20">
                          {state.badges.social}
                        </span>
                      )}
                    </div>
                    <span className="text-[10.5px] font-medium text-neutral-200 tracking-tight">Pulse</span>
                  </div>

                  {/* App 4: Camera */}
                  <div 
                    onClick={() => launchApp('camera')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    {renderAppIcon('camera')}
                    <span className="text-[10.5px] font-medium text-neutral-200 tracking-tight">Camera</span>
                  </div>

                  {/* App 5: Phone */}
                  <div 
                    onClick={() => launchApp('phone')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    {renderAppIcon('phone')}
                    <span className="text-[10.5px] font-medium text-neutral-200 tracking-tight">Phone</span>
                  </div>

                  {/* App 6: Notes */}
                  <div 
                    onClick={() => launchApp('notes')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    {renderAppIcon('notes')}
                    <span className="text-[10.5px] font-medium text-neutral-200 tracking-tight">Notes</span>
                  </div>

                  {/* App 7: Wallet */}
                  <div 
                    onClick={() => launchApp('wallet')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    {renderAppIcon('wallet')}
                    <span className="text-[10.5px] font-medium text-neutral-200 tracking-tight">Wallet</span>
                  </div>

                  {/* App 8: Settings */}
                  <div 
                    onClick={() => launchApp('settings')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    {renderAppIcon('settings')}
                    <span className="text-[10.5px] font-medium text-neutral-200 tracking-tight">Settings</span>
                  </div>

                </div>

                {/* 4. Bottom Dock (FROSTED GLASS ON iOS, MATERIAL ON ANDROID) */}
                <div className={`${
                  isIOS 
                    ? 'bg-white/20 border border-white/25 backdrop-blur-2xl rounded-[28px] p-2 flex justify-around items-center shrink-0 shadow-lg' 
                    : 'bg-neutral-900/70 border border-white/10 backdrop-blur-xl rounded-3xl p-2 flex justify-around items-center shrink-0'
                }`}>
                  <div onClick={() => launchApp('phone')} className="cursor-pointer">
                    {renderAppIcon('phone', true)}
                  </div>
                  <div onClick={() => launchApp('messages')} className="cursor-pointer">
                    {renderAppIcon('messages', true)}
                  </div>
                  <div onClick={() => launchApp('maps')} className="cursor-pointer">
                    {renderAppIcon('maps', true)}
                  </div>
                  <div onClick={() => launchApp('settings')} className="cursor-pointer">
                    {renderAppIcon('settings', true)}
                  </div>
                </div>

              </div>
            )}

            {/* SCREEN 3: Active Application Routing */}
            {state.currentView === 'app' && (
              <div className="flex-1 flex flex-col bg-neutral-950 text-white overflow-hidden relative">

                {/* 1. MESSAGES APP */}
                {state.activeApp === 'messages' && (
                  <div className="flex-1 flex flex-col h-full bg-neutral-950">
                    {activeChatId ? (
                      (() => {
                        const chat = chats.find(c => c.id === activeChatId) || chats[0];
                        return (
                          <div className="flex-1 flex flex-col h-full">
                            <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 bg-neutral-900/60">
                              <button 
                                onClick={() => {
                                  Sound.playTap();
                                  setActiveChatId(null);
                                }}
                                className="flex items-center gap-1 text-xs text-sky-400 font-medium cursor-pointer"
                              >
                                <ArrowLeft className="w-3.5 h-3.5" /> Back
                              </button>
                              <div className="text-center">
                                <div className="text-xs font-bold text-white">{chat.name}</div>
                                <div className="text-[10px] text-emerald-400">{chat.subtitle}</div>
                              </div>
                              <div className="w-8" />
                            </div>

                            {/* Message bubbles */}
                            <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
                              {chat.messages.map((m, idx) => (
                                <div 
                                  key={idx} 
                                  className={`flex ${m.sender === 'me' ? 'justify-end' : 'justify-start'}`}
                                >
                                  <div 
                                    className={`max-w-[82%] p-2.5 rounded-2xl text-xs leading-relaxed ${
                                      m.sender === 'me' 
                                        ? 'bg-sky-600 text-white rounded-br-xs' 
                                        : 'bg-neutral-800 text-neutral-100 rounded-bl-xs'
                                    }`}
                                  >
                                    {m.text}
                                    {m.hasAddress && (
                                      <div 
                                        onClick={() => launchApp('maps', m.mapsTarget)}
                                        className="mt-2 p-2 rounded-xl bg-sky-950/60 border border-sky-400/30 flex items-center justify-between text-[11px] font-semibold text-sky-300 cursor-pointer hover:bg-sky-900/50"
                                      >
                                        <span>📍 {m.addressText}</span>
                                        <ExternalLink className="w-3 h-3 text-sky-400" />
                                      </div>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>

                            {/* Suggested Reply Chips */}
                            <div className="p-2.5 border-t border-white/10 bg-neutral-900/80">
                              {chat.replies.length > 0 ? (
                                <div className="space-y-1.5">
                                  <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                                    Choose response:
                                  </div>
                                  {chat.replies.map((reply, rIdx) => (
                                    <button 
                                      key={rIdx}
                                      onClick={() => {
                                        Sound.playMessageSend();
                                        consume(reply.batteryCost, 'messages');
                                        advanceTimeMins(reply.timeCost, 'messages');

                                        // Update chat
                                        setChats(prev => prev.map(c => {
                                          if (c.id === chat.id) {
                                            return {
                                              ...c,
                                              messages: [...c.messages, { sender: 'me', text: reply.text }],
                                              replies: []
                                            };
                                          }
                                          return c;
                                        }));

                                        if (chat.id === 'boss') {
                                          onUpdateState(prev => ({
                                            ...prev,
                                            flags: { ...prev.flags, repliedToBoss: true },
                                            socialConnection: prev.socialConnection + 10
                                          }));
                                          completeTask(1);
                                        }

                                        // Delayed simulated answer
                                        if (reply.response) {
                                          setTimeout(() => {
                                            setChats(prev => prev.map(c => {
                                              if (c.id === chat.id) {
                                                return {
                                                  ...c,
                                                  messages: [...c.messages, { sender: 'them', text: reply.response! }]
                                                };
                                              }
                                              return c;
                                            }));
                                            Sound.playNotificationChime();
                                          }, reply.responseDelay || 2000);
                                        }
                                      }}
                                      className="w-full text-left p-2 rounded-xl bg-white/5 hover:bg-sky-500/20 border border-white/10 hover:border-sky-400/40 text-xs text-white transition-all flex items-center justify-between cursor-pointer"
                                    >
                                      <span>💬 "{reply.text}"</span>
                                    </button>
                                  ))}
                                </div>
                              ) : (
                                <div className="text-center text-[11px] text-neutral-500 py-1">
                                  Conversation up to date.
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })()
                    ) : (
                      /* Chat Conversations List */
                      <div className="flex-1 flex flex-col">
                        <div className="flex justify-between items-center px-4 py-2.5 border-b border-white/10">
                          <span className="text-sm font-bold text-white">Messages</span>
                          <span className="text-xs text-sky-400 font-semibold cursor-pointer" onClick={() => launchApp('phone')}>Call</span>
                        </div>
                        <div className="divide-y divide-white/5 overflow-y-auto">
                          {chats.map(chat => (
                            <div 
                              key={chat.id}
                              onClick={() => {
                                Sound.playTap();
                                setActiveChatId(chat.id);
                                setChats(prev => prev.map(c => c.id === chat.id ? { ...c, unread: false } : c));
                              }}
                              className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 cursor-pointer"
                            >
                              <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center text-lg">
                                {chat.avatar}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-baseline">
                                  <span className={`text-xs ${chat.unread ? 'font-bold text-white' : 'font-medium text-neutral-300'}`}>
                                    {chat.name}
                                  </span>
                                  <span className="text-[10px] text-neutral-500 font-mono">8:03 AM</span>
                                </div>
                                <div className="text-[11px] text-neutral-400 truncate">
                                  {chat.messages[chat.messages.length - 1]?.text}
                                </div>
                              </div>
                              {chat.unread && (
                                <div className="w-2 h-2 rounded-full bg-sky-400" />
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 2. MAPS APP (WITH REAL MULTI-STEP MOVING POINTER & DILEMMAS) */}
                {state.activeApp === 'maps' && (
                  <div className="flex-1 flex flex-col h-full bg-[#080e18]">
                    {/* Search & Header */}
                    <div className="p-3 border-b border-white/10 bg-neutral-900/60">
                      <div className="flex items-center gap-2 bg-neutral-800/80 px-3 py-2 rounded-xl text-xs">
                        <Search className="w-3.5 h-3.5 text-neutral-400" />
                        <span className="font-semibold text-white truncate flex-1">{currentDest.name}</span>
                        <span className="text-[10px] text-neutral-400 font-mono">{currentDest.distanceKm}</span>
                      </div>
                    </div>

                    {/* Interactive SVG City Map with Physical Animated Moving Location Pointer */}
                    <div className="relative h-[230px] bg-[#0b1322] border-b border-white/10 overflow-hidden">
                      <svg className="w-full h-full" viewBox="0 0 340 230" preserveAspectRatio="xMidYMid slice">
                        <defs>
                          <pattern id="city-grid-pattern" width="20" height="20" patternUnits="userSpaceOnUse">
                            <rect width="20" height="20" fill="#0b1322" />
                            <rect x="0" y="0" width="19" height="19" fill="#0f192b" />
                          </pattern>
                        </defs>
                        <rect width="100%" height="100%" fill="url(#city-grid-pattern)" />

                        {/* River */}
                        <path d="M-10,120 Q80,100 160,130 T350,110 L350,160 Q200,180 100,150 Z" fill="#0e2a47" opacity="0.6" />

                        {/* Roads */}
                        <line x1="170" y1="0" x2="170" y2="230" stroke="#334155" strokeWidth="12" />
                        <line x1="0" y1="120" x2="340" y2="120" stroke="#334155" strokeWidth="8" />
                        <line x1="0" y1="60" x2="340" y2="60" stroke="#1e293b" strokeWidth="4" />
                        <line x1="0" y1="180" x2="340" y2="180" stroke="#1e293b" strokeWidth="4" />

                        {/* Subway Track Line */}
                        <line x1="80" y1="150" x2="252" y2="65" stroke="#2563eb" strokeWidth="3" strokeDasharray="6 3" opacity="0.8" />

                        {/* Dynamic Animated GPS route line if active */}
                        {state.activeNavigation && (
                          <line 
                            x1={state.playerPos.x} 
                            y1={state.playerPos.y} 
                            x2={currentDest.svgPos.x} 
                            y2={currentDest.svgPos.y} 
                            stroke="#38bdf8" 
                            strokeWidth="3.5" 
                            strokeDasharray="6 4" 
                            className="animate-[dash_1s_linear_infinite]"
                          />
                        )}

                        {/* Animated Player Location Pointer (PHYSICALLY GLIDES ON THE MAP CANVAS) */}
                        <g 
                          className="transition-all duration-700 ease-out"
                          style={{ transform: `translate(${state.playerPos.x}px, ${state.playerPos.y}px)` }}
                        >
                          <circle cx="0" cy="0" r="18" fill="#38bdf8" opacity="0.3" className="animate-ping" />
                          <circle cx="0" cy="0" r="7" fill="#0284c7" stroke="#38bdf8" strokeWidth="2.5" />
                          <circle cx="0" cy="0" r="3.5" fill="#ffffff" />
                          <rect x="-35" y="-22" width="70" height="14" rx="4" fill="#000000" opacity="0.85" />
                          <text x="0" y="-12" fill="#38bdf8" fontSize="7.5" fontWeight="bold" textAnchor="middle">
                            YOU ARE HERE
                          </text>
                        </g>
                      </svg>

                      {/* Map Destination Pins */}
                      {MAP_DESTINATIONS.map(d => (
                        <div 
                          key={d.id}
                          onClick={() => {
                            Sound.playTap();
                            setSelectedDestId(d.id);
                          }}
                          className={`absolute -translate-x-1/2 -translate-y-full cursor-pointer transition-transform ${
                            selectedDestId === d.id ? 'scale-110 z-20' : 'opacity-85 z-10'
                          }`}
                          style={{ top: d.pinPos.top, left: d.pinPos.left }}
                        >
                          <div className={`px-2 py-0.5 rounded-md text-[10px] font-bold shadow-md whitespace-nowrap mb-0.5 ${
                            selectedDestId === d.id ? 'bg-sky-400 text-black' : 'bg-neutral-900/90 text-white border border-white/20'
                          }`}>
                            {d.icon} {d.name.split('(')[0]}
                          </div>
                          <div className="text-center text-lg leading-none">📍</div>
                        </div>
                      ))}
                    </div>

                    {/* Selected Destination Details & Actions */}
                    <div className="flex-1 p-3.5 flex flex-col justify-between bg-neutral-900/80">
                      <div>
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="text-sm font-bold text-white">{currentDest.name}</div>
                            <div className="text-xs text-sky-400 font-medium">
                              {currentDest.distanceKm} · {currentDest.etaMins} mins · {currentDest.category}
                            </div>
                          </div>
                          {currentDest.hasOutlet && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                              🔌 Outlets
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-neutral-400 mt-1 leading-relaxed">
                          {currentDest.description}
                        </p>
                      </div>

                      <div className="space-y-2 mt-2">
                        {/* Arrival Button if player reached Suite 400 */}
                        {isPlayerAtApex && (
                          <button 
                            onClick={() => onUpdateState(prev => ({ ...prev, doorKeypadOpen: true }))}
                            className="w-full py-2.5 bg-emerald-400 hover:bg-emerald-300 text-black font-extrabold text-xs rounded-xl shadow-lg cursor-pointer transition-all flex items-center justify-center gap-1.5 animate-bounce"
                          >
                            <DoorOpen className="w-3.5 h-3.5" />
                            <span>Unlock Suite 400 Keypad &amp; Enter (View Ending) →</span>
                          </button>
                        )}

                        <div className="grid grid-cols-2 gap-2">
                          <button 
                            onClick={() => {
                              Sound.playTap();
                              if (!state.settings.locationServices) {
                                onTriggerNotification("GPS Off", "Enable Location Services in Quick Settings.", "settings");
                                return;
                              }
                              onUpdateState(prev => ({
                                ...prev,
                                activeNavigation: !prev.activeNavigation,
                                screenAddictionScore: Math.min(100, prev.screenAddictionScore + 2)
                              }));
                              consume(0.04, 'maps', 0.5);
                              triggerGuiltToast("Live satellite GPS consumes battery while commuters walk right past who know the way.");
                            }}
                            className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                              state.activeNavigation 
                                ? 'bg-rose-500 text-white' 
                                : 'bg-sky-500 text-black hover:bg-sky-400'
                            }`}
                          >
                            <Navigation className="w-3.5 h-3.5" />
                            {state.activeNavigation ? 'Stop GPS' : 'Start GPS'}
                          </button>

                          {/* Real Moving Walk Button */}
                          <button 
                            disabled={state.isWalkingProgress}
                            onClick={handleWalkStep}
                            className="py-2 px-3 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/15 text-white border border-white/15 cursor-pointer disabled:opacity-50"
                          >
                            {state.isWalkingProgress ? 'Walking...' : `🚶 Walk (${currentDest.etaMins}m)`}
                          </button>
                        </div>

                        {/* The Human Connection Alternative */}
                        <button 
                          onClick={() => {
                            Sound.playTap();
                            advanceTimeMins(1, 'idle');
                            onUpdateState(prev => ({
                              ...prev,
                              socialConnection: Math.min(100, prev.socialConnection + 25),
                              stress: Math.max(0, prev.stress - 8),
                              screenAddictionScore: Math.max(0, prev.screenAddictionScore - 10),
                              flags: { ...prev.flags, askedStrangerForHelp: true },
                              humanMomentsLogged: [...prev.humanMomentsLogged, "Asked commuter on sidewalk who smiled and pointed to Suite 400"]
                            }));
                            completeTask(5);
                            Sound.playSocialBoost();
                            onTriggerNotification("Human Connection!", "Friendly pedestrian pointed directly to Suite 400!", "notes");
                            triggerGuiltToast("You spoke to a human instead of an algorithm. Your anxiety decreased immediately.");
                          }}
                          className="w-full py-2 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <span>🤝 Ask Friendly Stranger on Street (+25% Connection)</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. SOCIAL MEDIA APP ("PULSE") */}
                {state.activeApp === 'social' && (
                  <div className="flex-1 flex flex-col h-full bg-black">
                    <div className="flex justify-between items-center px-4 py-2 border-b border-white/10 bg-neutral-900/60 shrink-0">
                      <span className="text-sm font-extrabold tracking-tight bg-gradient-to-r from-pink-500 to-amber-400 bg-clip-text text-transparent">
                        Pulse Feed
                      </span>
                      <div className="text-[10px] text-amber-400 font-mono">
                        Dopamine: {state.dopaminePoints} pts
                      </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-3 space-y-3">
                      {posts.map(post => (
                        <div key={post.id} className="bg-neutral-900 border border-white/10 rounded-2xl p-3 space-y-2">
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{post.avatar}</span>
                            <div>
                              <div className="text-xs font-bold text-white">{post.author}</div>
                              <div className="text-[10px] text-neutral-400">{post.handle} · {post.timeAgo}</div>
                            </div>
                          </div>

                          <p className="text-xs text-neutral-200 leading-relaxed">
                            {post.text}
                          </p>

                          {post.mediaEmoji && (
                            <div 
                              className="h-24 rounded-xl flex items-center justify-center text-4xl shadow-inner"
                              style={{ background: post.mediaBg }}
                            >
                              {post.mediaEmoji}
                            </div>
                          )}

                          <div className="flex justify-between items-center pt-1 border-t border-white/5 text-xs text-neutral-400">
                            <button 
                              onClick={() => {
                                Sound.playDopamineChime();
                                consume(0.02, 'social');
                                setPosts(prev => prev.map(p => p.id === post.id ? { ...p, liked: !p.liked, likes: p.liked ? p.likes - 1 : p.likes + 1 } : p));
                                onUpdateState(prev => ({ ...prev, dopaminePoints: prev.dopaminePoints + 10 }));
                                triggerGuiltToast("Liking posts gave a tiny dopamine hit, but cost precious battery before your interview.");
                              }}
                              className={`flex items-center gap-1 cursor-pointer ${post.liked ? 'text-rose-500' : 'hover:text-white'}`}
                            >
                              <Heart className={`w-3.5 h-3.5 ${post.liked ? 'fill-current' : ''}`} />
                              <span>{post.likes}</span>
                            </button>
                            
                            <span className="text-[10px] text-neutral-500">
                              {post.commentsCount || 12} comments
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 4. CAMERA APP (WITH LIVE SCANNER & OCR CLUES) */}
                {state.activeApp === 'camera' && (
                  <div className="flex-1 flex flex-col h-full bg-black relative justify-between p-4">
                    {/* Viewfinder simulation */}
                    <div className="flex justify-between items-center text-xs text-neutral-400 z-10">
                      <span className="font-mono">4K · 60FPS</span>
                      <button 
                        onClick={() => {
                          Sound.playTap();
                          onUpdateState(prev => ({
                            ...prev,
                            cameraSceneIndex: (prev.cameraSceneIndex + 1) % cameraScenes.length
                          }));
                        }}
                        className="text-emerald-400 hover:text-emerald-300 font-bold bg-white/10 px-2 py-1 rounded-lg text-[10px] cursor-pointer"
                      >
                        Next Scene ⇄
                      </button>
                    </div>

                    {/* Viewfinder Center Display */}
                    {(() => {
                      const scene = cameraScenes[state.cameraSceneIndex] || cameraScenes[0];
                      return (
                        <div className="relative flex-1 my-3 rounded-2xl overflow-hidden border border-white/20 bg-neutral-900 flex flex-col justify-center items-center p-4 text-center">
                          {isPhotoFlashing && (
                            <div className="absolute inset-0 bg-white z-50 animate-in fade-in duration-75" />
                          )}
                          <div className="text-5xl mb-2">{scene.photoEmoji}</div>
                          <div className="text-xs font-bold text-white">{scene.name}</div>
                          <p className="text-[11px] text-neutral-400 mt-1 max-w-[220px]">{scene.desc}</p>

                          {/* OCR Clue Badge */}
                          {scene.hasClue && (
                            <div className="mt-3 p-2 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-[11px] text-emerald-300 font-mono">
                              🔍 OCR SCAN: {scene.clueText}
                            </div>
                          )}
                        </div>
                      );
                    })()}

                    {/* Shutter Controls */}
                    <div className="flex justify-around items-center pt-2 z-10">
                      <div className="w-10 h-10 rounded-full bg-neutral-800 border border-white/20 flex items-center justify-center text-xs">
                        {state.savedPhotos.length} 📷
                      </div>

                      <button 
                        onClick={() => {
                          Sound.playCameraShutter();
                          setIsPhotoFlashing(true);
                          setTimeout(() => setIsPhotoFlashing(false), 120);
                          consume(0.04, 'camera', 0.6);
                          const scene = cameraScenes[state.cameraSceneIndex];
                          onUpdateState(prev => ({
                            ...prev,
                            savedPhotos: [...prev.savedPhotos, {
                              id: Date.now(),
                              sceneName: scene.name,
                              clueText: scene.clueText,
                              time: formatSimTime(prev.timeMinutes)
                            }]
                          }));
                          if (scene.id === 0) {
                            completeTask(3);
                            onTriggerNotification("Clue Captured!", `Photo saved! Elevator code is ${state.doorSecurityCode}.`, "notes");
                          }
                        }}
                        className="w-16 h-16 rounded-full border-4 border-white bg-white/20 active:scale-95 transition-transform flex items-center justify-center cursor-pointer shadow-xl"
                      >
                        <div className="w-12 h-12 rounded-full bg-white" />
                      </button>

                      <button 
                        onClick={goHome}
                        className="text-xs text-neutral-400 hover:text-white cursor-pointer"
                      >
                        Exit
                      </button>
                    </div>
                  </div>
                )}

                {/* 5. PHONE APP (DIALER & RECENT CALLS) */}
                {state.activeApp === 'phone' && (
                  <div className="flex-1 flex flex-col h-full bg-neutral-950 p-4 justify-between">
                    <div>
                      <div className="text-center text-sm font-bold text-white mb-2">Phone</div>
                      <div className="h-10 bg-neutral-900 border border-white/10 rounded-xl flex items-center justify-center text-lg font-mono tracking-widest text-emerald-400">
                        {state.dialNumber || 'Dial a number...'}
                      </div>
                    </div>

                    {/* Numeric Keypad with DTMF tones */}
                    <div className="grid grid-cols-3 gap-2.5 max-w-[220px] mx-auto w-full my-auto">
                      {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map(digit => (
                        <button 
                          key={digit}
                          onClick={() => {
                            Sound.playDTMF(digit);
                            onUpdateState(prev => ({
                              ...prev,
                              dialNumber: (prev.dialNumber + digit).slice(0, 10)
                            }));
                          }}
                          className="w-13 h-13 rounded-full bg-neutral-900 border border-white/10 hover:border-emerald-400/40 text-base font-bold text-white flex items-center justify-center cursor-pointer active:bg-neutral-800 mx-auto"
                        >
                          {digit}
                        </button>
                      ))}
                    </div>

                    {/* Call and Clear actions */}
                    <div className="flex justify-around items-center pt-2">
                      <button 
                        onClick={() => onUpdateState(prev => ({ ...prev, dialNumber: '' }))}
                        className="text-xs text-neutral-400 hover:text-white font-medium cursor-pointer"
                      >
                        Clear
                      </button>

                      <button 
                        onClick={() => {
                          Sound.playRingtone();
                          consume(0.03, 'phone');
                          const cleanCode = state.doorSecurityCode.replace('#', '');
                          if (state.dialNumber === cleanCode || state.dialNumber === state.doorSecurityCode) {
                            completeTask(3);
                            onTriggerNotification("Apex Gate Operator", `Security desk confirms PIN ${state.doorSecurityCode} accepted!`, "notes");
                          } else {
                            onTriggerNotification("Call Connected", "Spoke with front desk receptionist.", "phone");
                          }
                        }}
                        className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-black flex items-center justify-center shadow-xl active:scale-95 cursor-pointer"
                      >
                        <Phone className="w-6 h-6" />
                      </button>

                      <button 
                        onClick={() => {
                          Sound.playSocialBoost();
                          onTriggerNotification("Mom Calling", "Mom: 'Good luck today honey! Take a deep breath!'", "phone");
                          onUpdateState(prev => ({ ...prev, socialConnection: Math.min(100, prev.socialConnection + 20) }));
                          completeTask(5);
                        }}
                        className="text-xs text-emerald-400 hover:text-emerald-300 font-bold cursor-pointer"
                      >
                        Call Mom
                      </button>
                    </div>
                  </div>
                )}

                {/* 6. NOTES APP (CANDIDATE CHEAT SHEET & CODE CLIPBOARD) */}
                {state.activeApp === 'notes' && (
                  <div className="flex-1 flex flex-col h-full bg-[#181512] p-4 text-neutral-100">
                    <div className="flex justify-between items-center border-b border-white/10 pb-2 mb-3">
                      <div>
                        <div className="text-xs font-bold text-amber-400">Interview Cheat Sheet</div>
                        <div className="text-[10px] text-neutral-400">Apex Tech Partner Panel</div>
                      </div>
                      <button 
                        onClick={() => {
                          Sound.playTap();
                          setCopiedCodeToast(true);
                          setTimeout(() => setCopiedCodeToast(false), 2000);
                          completeTask(3);
                        }}
                        className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Copy className="w-3 h-3" />
                        <span>{copiedCodeToast ? `Copied ${state.doorSecurityCode}!` : 'Copy PIN'}</span>
                      </button>
                    </div>

                    <textarea 
                      value={state.userCustomNotes}
                      onChange={(e) => onUpdateState(prev => ({ ...prev, userCustomNotes: e.target.value }))}
                      className="flex-1 w-full bg-transparent text-xs font-mono leading-relaxed resize-none focus:outline-none text-neutral-200"
                    />

                    <div className="pt-2 border-t border-white/10 text-[10px] text-neutral-400 flex justify-between items-center">
                      <span>PIN: <strong className="text-amber-300">{state.doorSecurityCode}</strong></span>
                      <span>Target: Suite 400 · 9:15 AM</span>
                    </div>
                  </div>
                )}

                {/* 7. WALLET APP (TRANSIT & PERKS) */}
                {state.activeApp === 'wallet' && (
                  <div className="flex-1 flex flex-col h-full bg-neutral-950 p-4 space-y-3">
                    <div className="flex justify-between items-center border-b border-white/10 pb-2">
                      <span className="text-sm font-bold text-white">Apple / Google Wallet</span>
                      <span className="text-xs font-mono font-bold text-emerald-400">${state.money.toFixed(2)}</span>
                    </div>

                    {/* Digital Transit Card */}
                    <div className="bg-gradient-to-tr from-sky-600 to-indigo-700 rounded-2xl p-3.5 text-white shadow-xl space-y-3">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold">Metro Express Pass</span>
                        <span>Line 2 Direct</span>
                      </div>
                      <div className="font-mono text-xs opacity-75">•••• •••• •••• 9012</div>
                      <div className="flex justify-between items-center pt-1">
                        <span className="text-[10px]">Tap on turnstile</span>
                        <button 
                          onClick={() => {
                            Sound.playTap();
                            consume(0.04, 'wallet');
                            advanceTimeMins(3, 'wallet');
                            const apex = MAP_DESTINATIONS.find(d => d.id === 'apex')!;
                            onUpdateState(prev => ({
                              ...prev,
                              money: Math.max(0, prev.money - 2.75),
                              playerPos: apex.svgPos,
                              currentLocation: "Apex Tech Tower Subway Exit",
                              destinationReached: true,
                              interviewArrivedPrompt: true
                            }));
                            completeTask(4);
                            onTriggerNotification("Subway Boarded!", "Direct arrival at Suite 400 elevator bank!", "maps");
                          }}
                          className="px-3 py-1 bg-white text-black font-extrabold text-xs rounded-xl shadow cursor-pointer active:scale-95"
                        >
                          NFC Tap to Ride ($2.75)
                        </button>
                      </div>
                    </div>

                    {/* Café & Outlet order */}
                    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-3 flex justify-between items-center">
                      <div>
                        <div className="text-xs font-bold text-white">☕ Neon Bean Café</div>
                        <div className="text-[10px] text-neutral-400">Order brew &amp; plug into barista outlet (+4%)</div>
                        <div className="text-xs font-mono text-emerald-400 font-bold mt-0.5">$4.50</div>
                      </div>
                      <button 
                        onClick={() => {
                          Sound.playSocialBoost();
                          onUpdateState(prev => ({
                            ...prev,
                            money: Math.max(0, prev.money - 4.50),
                            battery: Math.min(100, prev.battery + 4.0),
                            socialConnection: prev.socialConnection + 20,
                            humanMomentsLogged: [...prev.humanMomentsLogged, "Barista shared their private outlet with a warm smile!"]
                          }));
                          completeTask(5);
                          onTriggerNotification("Café Power Shared", "+4% battery charged!", "wallet");
                        }}
                        className="px-3 py-1.5 bg-emerald-500 text-black font-bold text-xs rounded-xl cursor-pointer"
                      >
                        Order &amp; Charge
                      </button>
                    </div>
                  </div>
                )}

                {/* 8. SETTINGS APP (DIAGNOSTICS & POWER MANAGEMENT) */}
                {state.activeApp === 'settings' && (
                  <div className="flex-1 flex flex-col h-full bg-neutral-950 p-4 overflow-y-auto space-y-3">
                    <div className="border-b border-white/10 pb-2">
                      <div className="text-sm font-bold text-white">Battery &amp; Settings</div>
                      <div className="text-[10px] text-neutral-400 font-mono">
                        Hardware: {phoneConfig.name} ({phoneConfig.batteryHealth}% Health)
                      </div>
                    </div>

                    {/* Low Power Mode Toggle */}
                    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-3 flex justify-between items-center">
                      <div>
                        <div className="text-xs font-bold text-white">Low Power Mode</div>
                        <div className="text-[10px] text-neutral-400">Reduces background drain by 50%</div>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={state.settings.lowPowerMode}
                        onChange={(e) => {
                          Sound.playTap();
                          onUpdateState(prev => ({
                            ...prev,
                            settings: { ...prev.settings, lowPowerMode: e.target.checked }
                          }));
                        }}
                        className="w-5 h-5 accent-emerald-500 cursor-pointer"
                      />
                    </div>

                    {/* Greyscale AMOLED Mode */}
                    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-3 flex justify-between items-center">
                      <div>
                        <div className="text-xs font-bold text-white">Greyscale Display</div>
                        <div className="text-[10px] text-neutral-400">Turns entire screen monochrome (-25% drain)</div>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={state.settings.greyscaleMode}
                        onChange={(e) => {
                          Sound.playTap();
                          onUpdateState(prev => ({
                            ...prev,
                            settings: { ...prev.settings, greyscaleMode: e.target.checked }
                          }));
                        }}
                        className="w-5 h-5 accent-emerald-500 cursor-pointer"
                      />
                    </div>

                    {/* Refresh Rate throttle */}
                    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-3 flex justify-between items-center">
                      <div>
                        <div className="text-xs font-bold text-white">Throttle 60Hz Screen</div>
                        <div className="text-[10px] text-neutral-400">Disables 120Hz ProMotion to save GPU</div>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={state.settings.refreshRate60Hz}
                        onChange={(e) => {
                          Sound.playTap();
                          onUpdateState(prev => ({
                            ...prev,
                            settings: { ...prev.settings, refreshRate60Hz: e.target.checked }
                          }));
                        }}
                        className="w-5 h-5 accent-emerald-500 cursor-pointer"
                      />
                    </div>

                    {/* Brightness slider */}
                    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-3 space-y-1.5">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-white">Screen Brightness</span>
                        <span className="font-mono text-emerald-400">{Math.round(state.settings.brightness * 100)}%</span>
                      </div>
                      <input 
                        type="range"
                        min="0.15"
                        max="1.0"
                        step="0.05"
                        value={state.settings.brightness}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          onUpdateState(prev => ({
                            ...prev,
                            settings: { ...prev.settings, brightness: val }
                          }));
                        }}
                        className="w-full accent-emerald-500 cursor-pointer"
                      />
                    </div>
                  </div>
                )}

              </div>
            )}

            {/* SCREEN 4: 0% Battery Dead / Shutdown Screen */}
            {state.currentView === 'shutdown' && (
              <div className="flex-1 flex flex-col justify-center items-center px-6 text-center bg-black text-white">
                <div className="text-5xl mb-3 text-rose-500 animate-pulse">🪫</div>
                <div className="text-lg font-bold text-white mb-1">Phone Has Died (0%)</div>
                <div className="text-xs text-amber-400 font-mono mb-2">Black Screen · Silence Restored</div>
                <p className="text-xs text-neutral-300 max-w-[250px] leading-relaxed mb-6">
                  The screen has gone cold. But you are still here, alive, in the real world. Your mind and voice remain completely intact.
                </p>
                <button 
                  onClick={() => {
                    Sound.playTap();
                    onUpdateState(prev => ({ ...prev, currentView: 'recap' }));
                  }}
                  className="w-full py-3 bg-white text-black font-bold text-xs rounded-xl hover:bg-neutral-200 transition-colors cursor-pointer"
                >
                  Read The Digital Autopsy →
                </button>
              </div>
            )}

            {/* SCREEN 5: Day Recap & Ending Evaluation Dashboard */}
            {state.currentView === 'recap' && (
              (() => {
                const ending = evaluateEnding(state);
                return (
                  <div className="flex-1 flex flex-col p-4 bg-neutral-950 text-white overflow-y-auto space-y-3">
                    <div className="text-center pt-2">
                      <div className="text-4xl mb-1">{ending.badgeIcon}</div>
                      <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: ending.color }}>
                        {ending.tag}
                      </span>
                      <div className="text-base font-extrabold text-white mt-0.5">
                        {ending.title}
                      </div>
                      <div className="text-[11px] text-emerald-400 font-semibold mt-0.5">
                        {ending.humanConnectionVerdict}
                      </div>
                    </div>

                    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-3 text-xs text-neutral-200 leading-relaxed">
                      {ending.narrative}
                    </div>

                    {/* The Digital Autopsy */}
                    <div className="bg-neutral-900 border border-amber-500/30 rounded-2xl p-3 text-xs text-amber-200/90 leading-relaxed space-y-1.5">
                      <div className="font-bold text-amber-400 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                        <span>👁️</span> The Digital Autopsy
                      </div>
                      <p className="text-[11.5px] leading-relaxed">
                        {ending.philosophicalGuilt}
                      </p>
                    </div>

                    {/* Stats Grid */}
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-neutral-900 border border-white/10 rounded-xl p-2 text-center">
                        <div className="text-base font-mono font-bold text-emerald-400">
                          {state.battery.toFixed(1)}%
                        </div>
                        <div className="text-[10px] text-neutral-400">Final Battery</div>
                      </div>
                      <div className="bg-neutral-900 border border-white/10 rounded-xl p-2 text-center">
                        <div className="text-base font-mono font-bold text-sky-400">
                          {state.socialConnection}/100
                        </div>
                        <div className="text-[10px] text-neutral-400">Human Connection</div>
                      </div>
                      <div className="bg-neutral-900 border border-white/10 rounded-xl p-2 text-center">
                        <div className="text-base font-mono font-bold text-amber-400">
                          {state.screenAddictionScore}%
                        </div>
                        <div className="text-[10px] text-neutral-400">Screen Addiction</div>
                      </div>
                      <div className="bg-neutral-900 border border-white/10 rounded-xl p-2 text-center">
                        <div className="text-base font-mono font-bold text-purple-400">
                          ${(35 - state.money).toFixed(2)}
                        </div>
                        <div className="text-[10px] text-neutral-400">Money Spent</div>
                      </div>
                    </div>

                    {/* Replay Scenario: RESTARTS CLEANLY AT TASK 0/5 WITH NEW CODE */}
                    <button 
                      onClick={handleReplayScenario}
                      className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs rounded-xl cursor-pointer shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>🔄 Replay Scenario (Task 0/5 &amp; New Random PIN)</span>
                    </button>
                  </div>
                );
              })()
            )}
          </div>

          {/* BOTTOM HARDWARE NAVIGATION BAR */}
          {state.selectedPhone === 'iphone7' ? (
            <div className="h-16 bg-black flex items-center justify-center relative shrink-0 z-[100]">
              <button 
                onClick={goHome}
                className="w-12 h-12 rounded-full border-2 border-neutral-700 bg-neutral-950 flex items-center justify-center shadow-inner active:scale-90 active:border-neutral-500 transition-all cursor-pointer group"
                title="Press tactile Home Button to return home"
                aria-label="Home Button"
              >
                <div className="w-4 h-4 rounded-[4px] border border-neutral-600 group-hover:border-neutral-400" />
              </button>
            </div>
          ) : state.device.os === 'android' ? (
            <div className="h-8 bg-black flex justify-around items-center px-8 z-50 shrink-0">
              <button onClick={() => { Sound.playTap(); if (state.currentView === 'app') goHome(); }} className="text-neutral-400 text-xs cursor-pointer">◁</button>
              <button onClick={goHome} className="text-neutral-400 text-xs cursor-pointer">◯</button>
              <button onClick={goHome} className="text-neutral-400 text-xs cursor-pointer">▢</button>
            </div>
          ) : (
            <div 
              onClick={goHome}
              className="h-5 flex items-center justify-center cursor-pointer z-50 bg-transparent group shrink-0"
              title="Click Home Bar to return home"
            >
              <div className="w-28 h-1 bg-white/40 group-hover:bg-white rounded-full transition-colors" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
