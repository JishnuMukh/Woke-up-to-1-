import React from 'react';
import { SimState, AppId, ScreenView, PhonePresetId } from '../types';
import { formatSimTime, PHONE_MODELS, getInitialSimState } from '../data/initialData';
import * as Sound from '../utils/audio';
import { 
  Smartphone, 
  BatteryMedium, 
  Clock, 
  MapPin, 
  DollarSign, 
  Users, 
  Sliders, 
  Eye, 
  Zap, 
  HeartHandshake,
  AlertTriangle,
  Flame,
  Coffee,
  MessageSquare,
  Sparkles,
  TrendingDown,
  Smile,
  CheckCircle2,
  Play,
  Check,
  DoorOpen
} from 'lucide-react';

interface DashboardInspectorProps {
  state: SimState;
  onUpdateState: (updater: (prev: SimState) => SimState) => void;
  onTriggerNotification: (title: string, msg: string, app?: AppId) => void;
  onOpenPhoneSelector?: () => void;
  onOpenBriefing?: () => void;
}

export const DashboardInspector: React.FC<DashboardInspectorProps> = ({
  state,
  onUpdateState,
  onTriggerNotification,
  onOpenPhoneSelector,
  onOpenBriefing
}) => {

  const previewLayout = (view: ScreenView, app?: AppId, controlCenter = false) => {
    Sound.playTap();
    onUpdateState(prev => ({
      ...prev,
      currentView: view,
      activeApp: app || null,
      isControlCenterOpen: controlCenter
    }));
  };

  const selectPhoneModel = (id: PhonePresetId) => {
    Sound.playTap();
    onUpdateState(() => getInitialSimState(id));
  };

  const setBatteryPreset = (level: number) => {
    Sound.playTap();
    onUpdateState(prev => ({
      ...prev,
      battery: level,
      isDead: level <= 0,
      currentView: level <= 0 ? 'shutdown' : prev.currentView
    }));
  };

  const concludeScenario = () => {
    Sound.playVictoryChime();
    onUpdateState(prev => ({
      ...prev,
      interviewCompleted: true,
      destinationReached: true,
      currentView: 'recap',
      activeApp: null
    }));
  };

  const activeConfig = PHONE_MODELS.find(p => p.id === state.selectedPhone) || PHONE_MODELS[0];
  const isPlayerAtApex = state.playerPos.x === 252 && state.playerPos.y === 55;

  return (
    <div className="flex flex-col gap-5 text-neutral-100">
      
      {/* 1. Clear Active Morning Mission Tasks & Objectives Card */}
      <div className="p-5 rounded-2xl bg-neutral-900/90 border border-emerald-500/30 backdrop-blur-md space-y-3.5 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Active Morning Objectives
            </h2>
          </div>
          {onOpenBriefing && (
            <button 
              onClick={onOpenBriefing}
              className="text-[11px] text-amber-400 hover:text-amber-300 font-bold hover:underline cursor-pointer"
            >
              Open Full Briefing 📋
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {/* Task 1 */}
          <div 
            onClick={() => previewLayout('app', 'messages')}
            className={`p-3 rounded-xl border flex flex-col justify-between cursor-pointer transition-all ${
              state.flags.repliedToBoss 
                ? 'bg-emerald-500/10 border-emerald-500/40 text-neutral-300' 
                : 'bg-white/5 border-white/10 hover:border-white/20'
            }`}
          >
            <div>
              <div className="flex justify-between items-center text-[10px] text-neutral-400 mb-1">
                <span>TASK 1</span>
                <span className={state.flags.repliedToBoss ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                  {state.flags.repliedToBoss ? '✓ COMPLETED' : 'PENDING'}
                </span>
              </div>
              <div className="text-xs font-bold text-white flex items-center gap-1">
                <span>💬</span> Reply to Mr. Sterling
              </div>
            </div>
            <span className="text-[10px] text-sky-400 mt-2 font-medium">Click to open Messages →</span>
          </div>

          {/* Task 2 */}
          <div 
            onClick={() => previewLayout('app', 'maps')}
            className={`p-3 rounded-xl border flex flex-col justify-between cursor-pointer transition-all ${
              state.destinationReached 
                ? 'bg-emerald-500/10 border-emerald-500/40 text-neutral-300' 
                : 'bg-white/5 border-white/10 hover:border-white/20'
            }`}
          >
            <div>
              <div className="flex justify-between items-center text-[10px] text-neutral-400 mb-1">
                <span>TASK 2</span>
                <span className={state.destinationReached ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                  {state.destinationReached ? '✓ ARRIVED' : 'IN PROGRESS'}
                </span>
              </div>
              <div className="text-xs font-bold text-white flex items-center gap-1">
                <span>🗺️</span> Navigate to Suite 400
              </div>
            </div>
            <span className="text-[10px] text-sky-400 mt-2 font-medium">Click to open Maps →</span>
          </div>

          {/* Task 3 */}
          <div 
            onClick={() => {
              if (state.destinationReached || isPlayerAtApex) {
                concludeScenario();
              } else {
                previewLayout('app', 'maps');
              }
            }}
            className={`p-3 rounded-xl border flex flex-col justify-between cursor-pointer transition-all ${
              state.interviewCompleted 
                ? 'bg-emerald-500/10 border-emerald-500/40 text-neutral-300' 
                : state.destinationReached
                  ? 'bg-emerald-500/20 border-emerald-400 ring-1 ring-emerald-400 animate-pulse'
                  : 'bg-white/5 border-white/10 hover:border-white/20'
            }`}
          >
            <div>
              <div className="flex justify-between items-center text-[10px] text-neutral-400 mb-1">
                <span>TASK 3</span>
                <span className={state.interviewCompleted ? 'text-emerald-400 font-bold' : state.destinationReached ? 'text-emerald-300 font-bold' : 'text-amber-400'}>
                  {state.interviewCompleted ? '✓ FINISHED' : state.destinationReached ? 'READY TO ENTER' : 'BEFORE 9:15 AM'}
                </span>
              </div>
              <div className="text-xs font-bold text-white flex items-center gap-1">
                <span>🏢</span> Arrive &amp; Enter Suite 400
              </div>
            </div>
            <span className="text-[10px] text-emerald-400 mt-2 font-bold">
              {state.destinationReached ? '🚪 Enter Interview Panel →' : 'Reach Apex Tower'}
            </span>
          </div>
        </div>

        {/* If Arrived or Finished, show immediate conclusion button */}
        {(state.destinationReached || isPlayerAtApex) && !state.interviewCompleted && (
          <button 
            onClick={concludeScenario}
            className="w-full py-2.5 bg-emerald-400 hover:bg-emerald-300 text-black font-extrabold text-xs rounded-xl shadow-lg cursor-pointer transition-all flex items-center justify-center gap-1.5 animate-bounce"
          >
            <DoorOpen className="w-4 h-4" />
            <span>Enter Suite 400 Elevator &amp; Conclude Scenario (View Ending) →</span>
          </button>
        )}
      </div>

      {/* 2. Device Selection Panel ("Choose Your Phone") */}
      <div className="p-5 rounded-2xl bg-neutral-900/90 border border-white/10 backdrop-blur-md space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Choose Your Phone Hardware
            </h2>
          </div>
          <span className="text-[10px] text-neutral-400 font-mono">
            {activeConfig.name} ({activeConfig.batteryHealth}% Health)
          </span>
        </div>

        <p className="text-xs text-neutral-300">
          Pick which device you wake up with. Notice how the hardware chassis, screen bezels, and battery health immediately change on the simulator:
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {PHONE_MODELS.map(phone => {
            const isSelected = phone.id === state.selectedPhone;
            return (
              <button
                key={phone.id}
                onClick={() => selectPhoneModel(phone.id)}
                className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                  isSelected 
                    ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-md' 
                    : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
                }`}
              >
                <div>
                  <div className="text-xs font-bold leading-tight truncate">
                    {phone.name.split('(')[0]}
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-0.5">
                    {phone.batteryHealth}% Health
                  </div>
                </div>
                <div className="mt-2 text-[10px] font-mono text-emerald-400 font-bold">
                  {phone.startingBattery}% Batt
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Human Connection vs Screen Addiction Index */}
      <div className="p-5 rounded-2xl bg-neutral-900/90 border border-white/10 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-neutral-300 uppercase tracking-wider">
            <HeartHandshake className="w-4 h-4 text-rose-400" />
            <span>Human Connection vs Screen Trap</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">Behavioral Mirror</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20">
            <div className="flex justify-between items-center text-xs font-bold text-emerald-400 mb-1">
              <span className="flex items-center gap-1.5"><Smile className="w-3.5 h-3.5" /> Real Human Connection</span>
              <span className="font-mono text-sm">{state.socialConnection}/100</span>
            </div>
            <div className="w-full bg-neutral-800 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-emerald-400 h-full rounded-full transition-all duration-500" 
                style={{ width: `${Math.min(100, state.socialConnection)}%` }}
              />
            </div>
            <p className="text-[10px] text-neutral-400 mt-1.5">
              Gained by speaking with commuters, ordering coffee with a smile, or pocketing the phone.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-500/20">
            <div className="flex justify-between items-center text-xs font-bold text-rose-400 mb-1">
              <span className="flex items-center gap-1.5"><TrendingDown className="w-3.5 h-3.5" /> Screen Addiction &amp; FOMO</span>
              <span className="font-mono text-sm">{state.screenAddictionScore}/100</span>
            </div>
            <div className="w-full bg-neutral-800 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-rose-500 h-full rounded-full transition-all duration-500" 
                style={{ width: `${Math.min(100, state.screenAddictionScore)}%` }}
              />
            </div>
            <p className="text-[10px] text-neutral-400 mt-1.5">
              Increased by watching viral video reels, clicking FOMO bait, and obsessing over GPS.
            </p>
          </div>
        </div>
      </div>

      {/* 4. Screen Layout Switcher */}
      <div className="p-5 rounded-2xl bg-neutral-900/80 border border-white/10 space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-neutral-300 uppercase tracking-wider">
          <div className="flex items-center gap-2">
            <Eye className="w-3.5 h-3.5 text-sky-400" />
            <span>Switch Screen Layout</span>
          </div>
          <span className="text-[10px] text-neutral-400 font-mono">Instant Preview</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          <button
            onClick={() => previewLayout('home', undefined, false)}
            className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
              state.currentView === 'home' && !state.isControlCenterOpen
                ? 'bg-emerald-500/20 border-emerald-400 text-white'
                : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
            }`}
          >
            <div className="font-bold text-emerald-400 flex items-center gap-1.5">
              <span>🏠</span> Home Dashboard
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">Glance widget &amp; tasks</div>
          </button>

          <button
            onClick={() => previewLayout('home', undefined, true)}
            className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
              state.isControlCenterOpen
                ? 'bg-amber-500/20 border-amber-400 text-white'
                : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
            }`}
          >
            <div className="font-bold text-amber-400 flex items-center gap-1.5">
              <span>⚡</span> Quick Settings
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">Control center drawer</div>
          </button>

          <button
            onClick={() => previewLayout('lock', undefined, false)}
            className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
              state.currentView === 'lock'
                ? 'bg-sky-500/20 border-sky-400 text-white'
                : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
            }`}
          >
            <div className="font-bold text-sky-400 flex items-center gap-1.5">
              <span>🔒</span> Lock Screen
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">Time &amp; priority alert</div>
          </button>

          <button
            onClick={() => previewLayout('app', 'maps', false)}
            className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
              state.currentView === 'app' && state.activeApp === 'maps'
                ? 'bg-teal-500/20 border-teal-400 text-white'
                : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
            }`}
          >
            <div className="font-bold text-teal-400 flex items-center gap-1.5">
              <span>🗺️</span> Maps &amp; GPS
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">City route &amp; outlets</div>
          </button>

          <button
            onClick={() => previewLayout('app', 'messages', false)}
            className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
              state.currentView === 'app' && state.activeApp === 'messages'
                ? 'bg-green-500/20 border-green-400 text-white'
                : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
            }`}
          >
            <div className="font-bold text-green-400 flex items-center gap-1.5">
              <span>💬</span> Messages Thread
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">Boss &amp; roommate chats</div>
          </button>

          <button
            onClick={() => previewLayout('app', 'social', false)}
            className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
              state.currentView === 'app' && state.activeApp === 'social'
                ? 'bg-pink-500/20 border-pink-400 text-white'
                : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
            }`}
          >
            <div className="font-bold text-pink-400 flex items-center gap-1.5">
              <span>📱</span> Pulse Social Feed
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">FOMO viral bait</div>
          </button>

          <button
            onClick={() => previewLayout('app', 'wallet', false)}
            className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
              state.currentView === 'app' && state.activeApp === 'wallet'
                ? 'bg-blue-500/20 border-blue-400 text-white'
                : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
            }`}
          >
            <div className="font-bold text-blue-400 flex items-center gap-1.5">
              <span>💳</span> Wallet &amp; Store
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">Power banks &amp; metro</div>
          </button>

          <button
            onClick={() => previewLayout('app', 'settings', false)}
            className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
              state.currentView === 'app' && state.activeApp === 'settings'
                ? 'bg-slate-500/20 border-slate-400 text-white'
                : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
            }`}
          >
            <div className="font-bold text-slate-300 flex items-center gap-1.5">
              <span>⚙️</span> Power Settings
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">Battery usage log</div>
          </button>

          <button
            onClick={() => previewLayout('recap', undefined, false)}
            className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer ${
              state.currentView === 'recap'
                ? 'bg-purple-500/20 border-purple-400 text-white'
                : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
            }`}
          >
            <div className="font-bold text-purple-400 flex items-center gap-1.5">
              <span>📊</span> Ending &amp; Autopsy
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">Final stats &amp; reflection</div>
          </button>
        </div>
      </div>

      {/* 5. Live Simulation Telemetry & Presets */}
      <div className="p-5 rounded-2xl bg-neutral-900/80 border border-white/10 space-y-4">
        <div className="flex items-center justify-between text-xs font-bold text-neutral-300 uppercase tracking-wider">
          <div className="flex items-center gap-2">
            <Sliders className="w-3.5 h-3.5 text-emerald-400" />
            <span>Live Telemetry &amp; Resources</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">Real-time</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-[10px] text-neutral-400 uppercase tracking-wider flex items-center gap-1">
              <BatteryMedium className="w-3 h-3 text-emerald-400" /> Battery
            </div>
            <div className="text-xl font-bold font-mono text-white mt-1 tabular-nums">
              {state.battery.toFixed(state.battery < 10 ? 1 : 0)}%
            </div>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-[10px] text-neutral-400 uppercase tracking-wider flex items-center gap-1">
              <Clock className="w-3 h-3 text-sky-400" /> Time
            </div>
            <div className="text-xl font-bold font-mono text-white mt-1 tabular-nums">
              {formatSimTime(state.timeMinutes)}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-[10px] text-neutral-400 uppercase tracking-wider flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-purple-400" /> Cash
            </div>
            <div className="text-xl font-bold font-mono text-white mt-1 tabular-nums">
              ${state.money.toFixed(2)}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-[10px] text-neutral-400 uppercase tracking-wider flex items-center gap-1">
              <Users className="w-3 h-3 text-amber-400" /> Location
            </div>
            <div className="text-xs font-bold text-white mt-1 truncate">
              {state.currentLocation.split(' ')[0]}
            </div>
          </div>
        </div>

        {/* Battery Quick Presets */}
        <div>
          <div className="text-[11px] font-semibold text-neutral-400 mb-2">
            Simulate Battery Panic Thresholds (All &lt;10%):
          </div>
          <div className="grid grid-cols-4 gap-2">
            <button 
              onClick={() => setBatteryPreset(1.0)}
              className="py-1.5 px-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              ⚡ 1.0% Clutch
            </button>
            <button 
              onClick={() => setBatteryPreset(3.0)}
              className="py-1.5 px-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              🪫 3.0% iPhone 7
            </button>
            <button 
              onClick={() => setBatteryPreset(5.0)}
              className="py-1.5 px-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              ⚠️ 5.0% Low
            </button>
            <button 
              onClick={() => setBatteryPreset(7.5)}
              className="py-1.5 px-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              🔋 7.5% Start
            </button>
          </div>
        </div>
      </div>

      {/* 6. Seductive Traps & Story Event Injections */}
      <div className="p-5 rounded-2xl bg-neutral-900/80 border border-white/10 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-neutral-300 uppercase tracking-wider">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>Seductive Digital Traps &amp; Human Alternatives</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          <button 
            onClick={() => {
              Sound.playNotificationChime();
              onTriggerNotification("Pulse Trending", "🔥 Leaked Apex Interview Questions just dropped! Tap to see.", "social");
            }}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-neutral-200 transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Flame className="w-4 h-4 text-rose-400 shrink-0" />
            <div>
              <div className="font-semibold text-white">Inject FOMO Clickbait</div>
              <div className="text-[10px] text-neutral-400">Pings user with irresistible bait</div>
            </div>
          </button>

          <button 
            onClick={() => {
              Sound.playSocialBoost();
              onTriggerNotification("Neon Bean Café", "Friendly barista visible behind counter! Real people ready to help.", "maps");
            }}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-neutral-200 transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Coffee className="w-4 h-4 text-amber-400 shrink-0" />
            <div>
              <div className="font-semibold text-white">Spot Neighborhood Café</div>
              <div className="text-[10px] text-neutral-400">Human connection opportunity</div>
            </div>
          </button>

          <button 
            onClick={() => {
              Sound.playNotificationChime();
              onTriggerNotification("Mr. Sterling", "Alex, we start in 10 minutes. Are you in the elevator?", "messages");
            }}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-neutral-200 transition-colors flex items-center gap-2 cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <div className="font-semibold text-white">Trigger Boss Countdown</div>
              <div className="text-[10px] text-neutral-400">Forces priority decision</div>
            </div>
          </button>

          <button 
            onClick={() => {
              Sound.playTap();
              onUpdateState(prev => ({
                ...prev,
                timeMinutes: prev.timeMinutes + 15
              }));
              onTriggerNotification("Time Passed", "Clock moved forward 15 minutes.", "notes");
            }}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-neutral-200 transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Clock className="w-4 h-4 text-purple-400 shrink-0" />
            <div>
              <div className="font-semibold text-white">Advance Clock (+15m)</div>
              <div className="text-[10px] text-neutral-400">Races closer to 9:15 AM deadline</div>
            </div>
          </button>
        </div>
      </div>

    </div>
  );
};
